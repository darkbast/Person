//ステージ初期状態
var g_stagedata = [
	[
		[5,4,3,2,1,0],	//0
		[0,0,0,0,0,0],	//1
		[0,0,0,0,0,0],	//2
		[0,0,0,0,0,0],	//3
		[0,0,0,0,0,0],	//4
		[0,0,0,0,0,0]		//5
	],
	[
		[5,4,3,2,1,0,0],	//0
		[5,4,3,2,1,0,0],	//1
		[1,4,3,2,5,0,0],	//2
		[0,0,0,0,0,0,0],	//3
		[0,0,0,0,0,0,0],	//4
		[0,0,0,0,0,0,0]	//5
	]
];
//現在のステージ状態を記憶する関数
var g_gamedata;
var g_nokori;	//残りの帽子の数
var g_srcholder; //移動元のホルダーの番号
var g_srchat;	//移動する帽子
var g_stage = 0;	//現在のステージ
var MAXSTAGE = 2;	//最大ステージ数
var g_stepcount;	//動かした回数
//効果音
var g_dragsound, g_dropsound, g_deathsound, g_clearsound;


//ロードイベント
window.addEventListener('load', initGame, false);

//最初に実行する関数
function initGame(){
	var dialog = document.querySelector('#title');
	dialog.style.display = 'block';
	//ボタンのイベント設定
	var btn = document.querySelector('#btn_gamestart');
	btn.addEventListener('click', gamestart_click, false);
	btn = document.querySelector('#btn_restart');
	btn.addEventListener('click', restart_click, false);
	btn = document.querySelector('#btn_nextstage');
	btn.addEventListener('click', nextstage_click, false);
	//サウンド
	g_dragsound = document.querySelector("#dragsound");
	g_dropsound = document.querySelector("#dropsound");
	g_deathsound = document.querySelector("#deathsound");
	g_clearsound = document.querySelector("#clearsound");
}

//タイトル画面のボタンがクリックされた
function gamestart_click(e){
	var dialog = document.querySelector('#title');
	dialog.style.display = 'none';
	gameStart();
}
//再スタートボタンがクリックされた
function restart_click(e){
	gameStart();
}

//ゲーム開始処理
function gameStart(){
	//配列変数をコピー
	g_gamedata = new Array();
	for(var i=0; i<g_stagedata[g_stage].length; i++){
		g_gamedata[i] = new Array();
		for(var j=0; j<g_stagedata[g_stage][i].length; j++){
			g_gamedata[i][j] = g_stagedata[g_stage][i][j];
		}
	}
	//面数、回数を表示
	g_stepcount = 0;
	var step = document.querySelector('#stepcount');
	step.innerHTML = g_stepcount;
	var stage = document.querySelector('#stagecount');
	stage.innerHTML = g_stage + 1;	
	//ハットホルダーに帽子を並べる
	g_nokori = 0;
	g_srcholder = -1;
	var holders = document.querySelectorAll('.hatholder li');
	for(var i=0; i<holders.length; i++){
		holders[i].holderid = i;
		setHolder(g_gamedata[i], holders[i]);
		if(g_mobiledevice == true){
			holders[i].addEventListener('touchend', hatholder_click, true);
		} else {
			holders[i].addEventListener('click', hatholder_click, true);
		}
		//帽子を数える
		for(var j=0; j<g_gamedata[i].length; j++){
			if(g_gamedata[i][j] > 0) g_nokori++;
		}
	}
}

//1つのハットホルダーに帽子を表示
function setHolder(holderdata, holderelem){
	//古いimgを削除
	var children = holderelem.querySelectorAll('img');
	for(var i=0; i<children.length; i++){
		holderelem.removeChild(children[i]);
	}
	//新たなimgを追加
	for(var i=0; i<holderdata.length; i++){
		if(holderdata[i] > 0){
			var obj = document.createElement('img');
			obj.src = 'img/hat' + holderdata[i] +'.png';
			obj.style.position = 'absolute';
			obj.style.left = '6px';
			obj.style.top = (236 - 52 * i) + 'px';
			holderelem.appendChild(obj);
		}
	}
}

//ハットホルダーがクリックされた
function hatholder_click(e){
	if(g_srcholder == -1){
		//1回目
		var holder = e.currentTarget;
		var srcdata = g_gamedata[holder.holderid];
		for(var i=srcdata.length-1; i>=0; i--){
			if(srcdata[i] > 0) {
				g_srcholder = holder.holderid;
				holder.className = 'selected';
				g_srchat = i;
				try{
					if(g_mobiledevice == true) g_dragsound.load();
					else g_dragsound.currentTime = 0;
					g_dragsound.play();
				} catch(e){
				}
				break;
			}
		}
	} else {
		//2回目
		//選択解除
		var srcholder = g_srcholder;
		g_srcholder = -1;
		var selected = document.querySelector('.selected');
		selected.className = '';
		//移動元と同じだったら脱出
		var holder = e.currentTarget;
		if(holder.holderid == srcholder){
			return;
		}
		//移動可能かチェックする
		var srcdata = g_gamedata[srcholder];
		var destdata = g_gamedata[holder.holderid];
		//移動できないときをチェック
		//一番上の帽子を探す
		for(var i=destdata.length-1; i>=0; i--){
			if(destdata[i] > 0) break;
		}
		//移動できない場合は関数脱出
		if(i == destdata.length - 1) return;
		if(i > 0 &&
			destdata[i] != srcdata[g_srchat] - 1)
		{
			return;
		}
		//移動する
		destdata[i+1] = srcdata[g_srchat];
		srcdata[g_srchat] = 0;
		//表示更新
		var holders = document.querySelectorAll('.hatholder li');
		setHolder(srcdata, holders[srcholder]);
		setHolder(destdata, holder);
		clearCheck(destdata, holder);
		//移動回数表示
		g_stepcount++;
		var step = document.querySelector('#stepcount');
		step.innerHTML = g_stepcount;
		try{
			if(g_mobiledevice == true) g_dropsound.load();
			else g_dropsound.currentTime = 0;
			g_dropsound.play();
		} catch(e){
		}
	}
}

//5～1まで揃ったかチェックする
function clearCheck(holderdata, holderelem){
	var counter = 1;
	var d = 0;
	//下から数えていく
	for(var i=0; i<holderdata.length; i++){
		if(holderdata[i]==counter){
			counter++;
			if(counter > 5) break;
		} else {
			if(holderdata[i]==1){
				counter = 2;
				d = i;
			}
		}
	}
	//5つ揃った？
	if(counter > 5){
		//消す
		for(i=d; i<d+5; i++){
			holderdata[i] = 0;
		}
		g_nokori -= 5;
		setHolder(holderdata, holderelem);
		try{
			if(g_mobiledevice == false) {
				g_deathsound.currentTime = 0;
				g_deathsound.play();
			}
		}catch(e){
		}
	}
	//ゲームクリア
	if(g_nokori <= 0){
		setTimeout(clearStage, 2000);
		try{
			if(g_mobiledevice == true) g_clearsound.load();
			else g_clearsound.currentTime = 0;
			g_clearsound.play();
		} catch(e){
		}
	}
}

//ゲームクリア画面の表示
function clearStage(){
	var dialog = document.querySelector('#gameclear');
	dialog.style.display = 'block';
}

//次のステージボタンが押された
function nextstage_click(e){
	g_stage++;
	var dialog = document.querySelector('#gameclear');
	dialog.style.display = 'none';
	if(g_stage < MAXSTAGE) gameStart();
	else {
		g_stage = 0;
		dialog = document.querySelector('#title');
		dialog.style.display = 'block';
	}
}
