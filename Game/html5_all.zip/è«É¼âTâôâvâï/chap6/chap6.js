var g_novelscriptline = 0;
var g_partscript;

//ロードイベント
window.addEventListener('load', initGame, false);

//最初に実行する関数
function initGame(){
	var dialog = document.querySelector('#title');
	dialog.style.display = 'block';
	var btn = document.querySelector('#btn_gamestart');
	btn.addEventListener('click', clickGameStart, false);
}

//ゲーム開始
function clickGameStart(e){
	var dialog = document.querySelector('#title');
	dialog.style.display = 'none';
	loadPartData('text/part1.html');	
}

//シーン読み込み
function loadPartData(partname){
	//Ajaxによる読み込み開始
	var req = new XMLHttpRequest();
	req.open('GET', partname, true);
	req.onreadystatechange = fileloaded;
	req.send();
}

//ファイルの読み込み完了
function fileloaded(){
	if (this.readyState == 4) {
		if(this.status == 200){
			var pholder = document.querySelector('.placeholder');
			pholder.innerHTML = this.responseText;
			var script = pholder.querySelector('.hiddenjson');
			var scdata = eval('(' + script.innerHTML + ')');
			g_partscript = scdata.partscript;
			g_novelscriptline = 0;
			readNovelScript();
		}
	    else{
			alert("ファイル読み込みエラー");
	    }
	}
}

//コマンドを1行ずつ解釈
function readNovelScript(){
	var part = document.querySelector('.partholder');
	var l = g_partscript.length;
	for(var i=g_novelscriptline; i<l; i++){
		g_novelscriptline++;
		var command = g_partscript[i].command;
		var sparam1 = g_partscript[i].sparam1;
		var sparam2 = g_partscript[i].sparam2;
		var iparam1 = g_partscript[i].iparam1;
		var iparam2 = g_partscript[i].iparam2;
		var result = execNovelCommand(part, command, 
			sparam1, sparam2, iparam1, iparam2);
		if(result == -1){
			alert('ノベルスクリプトエラー'+command + ", " + sparam1 + ", " + 
				iparam1 + ", " + iparam2);
		}
		//待機コマンドなら関数脱出
		if(result == 0) return;
	}
}

//1つのコマンドを実行
function execNovelCommand(part, command, sparam1, sparam2, iparam1, iparam2){
	if(command == '要素表示'){
		//要素を指定座標に表示する
		var image = part.querySelector('.' + sparam1);
		if(image == null) return -1;
		image.style.display = 'block';
		image.style.left = iparam1 + 'px';
		image.style.top = iparam2 + 'px';
		return 1;		
	} else if(command == '要素隠し'){
		//要素を隠す
		var image = part.querySelector('.' + sparam1);
		if(image == null) return -1;
		image.style.display = 'none';
		return 1;
	} else if(command == 'クラス設定'){
		//クラスを設定する
		var image = part.querySelector('.' + sparam1);
		if(image == null) return -1;
		var cname = image.className;
		cname +=  ' ' + sparam2;
		image.className = cname;
		return 1;		
	} else if(command == 'クラス除去'){
		//クラスを除去する
		var image = part.querySelector('.' + sparam1);
		if(image == null) return -1;
		var cname = image.className;
		cname = cname.replace(sparam2,'');
		cname = cname.replace('  ','');		//連続するスペース削除
		cname = cname.replace(/^ +/, '');	//行頭スペース削除
		cname = cname.replace(/ +$/, '');	//行末スペース削除
		image.className = cname;
		return 1;		
	} else if(command == 'ミリ待機'){
		//待機
		setTimeout(readNovelScript, iparam1);
		return 0;
	} else if(command == '待機ボタン'){
		//指定したボタンがクリックされるまで実行を待機する
		var image = part.querySelector('.' + sparam1);
		if(image == null) return -1;
		image.style.display = 'block';
		image.style.left = iparam1 + 'px';
		image.style.top = iparam2 + 'px';
		image.addEventListener('click', clickWaitButton, false);
		return 0;
	} else if(command == '切替ボタン'){
		//指定したボタンがクリックされたらそのシーンのHTMLファイルを読み込む
		var image = part.querySelector('.' + sparam1);
		if(image == null) return -1;
		image.style.display = 'block';
		image.style.left = iparam1 + 'px';
		image.style.top = iparam2 + 'px';
		//切替ボタンのイベント
		image.addEventListener('click', clickSceneChange, false);
		return 1;
	}
	return 1;
}

//切替ボタンのイベントリスナー
var g_href;
function clickSceneChange(e){
	e.target.removeEventListener('click', clickSceneChange, false);
	var pholder = document.querySelector('.placeholder');
	var oldpart = pholder.querySelector('.partholder');
	//スライドアウトアニメーションを設定
	var cname = oldpart.className;
	cname = cname.replace('anim_slidein', 'anim_slideout');
	oldpart.className = cname;
	//アニメーションが終了する0.5秒後にシーン切り替え
	g_href = e.target.getAttribute('data-href');
	setTimeout(changeScene, 500);
}
//シーン切り替えを実行
function changeScene(){
	var pholder = document.querySelector('.placeholder');
	var oldpart = pholder.querySelector('.partholder');
	pholder.removeChild(oldpart);
	loadPartData('text/' + g_href);
}

//待機ボタンのイベントリスナー
function clickWaitButton(e){
	e.target.style.display = 'none';
	e.target.removeEventListener('click', clickWaitButton, false);
	readNovelScript();
}