#include <GConsoleLib.h>
#include <stdio.h>

void DrawGraph(int);	//�֐��v���g�^�C�v�錾

int kazu[] = {72, 13, 62, 22, 15, 98, 36, 46, 31, 4};

int main(){
	gfront();
	gcls();

	gcolor(200, 200, 200);
	gbox(40, 40, 560, 400);

	for(int k = 9; k > 0; k--){
		//printf("%d�x��\n", 10 - k);
		for(int j = 0; j < k; j++){
			if(kazu[j] > kazu[j+1]){			
				//����ւ�
				int temp = kazu[j];
				kazu[j] = kazu[j+1];
				kazu[j+1] = temp;
			}
			//�\��
			DrawGraph(j);
		}
	}
}

void DrawGraph(int target){
	for(int i = 0; i < 10; i++){
		int y = 60 + i * 36;
		int w = kazu[i]*5;
		if( i == target ) gcolor(255, 128, 0);
		else gcolor(0, 128, 255);
		gbox(60, y, w, 32);
		gcolor(200, 200, 200);
		gbox(60+w, y, 540-w, 36);
		//printf("%d\t", kazu[i]);
	}
}