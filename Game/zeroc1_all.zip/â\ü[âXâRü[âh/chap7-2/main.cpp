#include <stdio.h>
#include <stdlib.h>

int g_global1 = 9999;
int g_global2 = 9999;

int main(){
	int local1 = 1000;
	int local2 = 1000;
	printf("code = %p\n", main);
	printf("global1 = %p\n", &g_global1);
	printf("global2 = %p\n", &g_global2);
	printf("local1  = %p\n", &local1);
	printf("local2  = %p\n", &local2);
	printf("malloc1 = %p\n", malloc( sizeof(int) ));
	printf("malloc2 = %p\n", malloc( sizeof(int) ));
}

