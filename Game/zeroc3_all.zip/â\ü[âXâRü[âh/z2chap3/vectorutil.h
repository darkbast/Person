#ifndef __LB_VECTORUITL_H_
#define __LB_VECTORUITL_H_
#include <windows.h>
#include <tchar.h>
#include <gdiplus.h>
#include <math.h>

void RotateVector(float*,float*,float);
float DotProduct(float v1x, float v1y, 
				 float v2x, float v2y);
float CrossProduct(float v1x, float v1y, 
				 float v2x, float v2y);
void AddVector(float v1x, float v1y,
			   float v2x, float v2y,
			   float *rx, float *ry);
void SubVector(float v1x, float v1y,
			   float v2x, float v2y,
			   float *rx, float *ry);
BOOL HitTestLineAndBall(
			float sx, float sy, 
			float ex, float ey,
			float bx, float by,
			float bsize);
void ReflectVector(
			float vecx, float vecy,
			float sx, float sy, float ex, float ey,
			float *refvecx, float *refvecy);

//�萔�錾
const float ZEROVALUE = 1e-10f;
const float PIE = 3.1415926f;

#endif