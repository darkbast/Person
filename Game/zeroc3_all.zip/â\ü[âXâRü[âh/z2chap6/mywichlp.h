#ifndef __MY_WIC_HLP__
#define __MY_WIC_HLP__
#include <windows.h>
#include <tchar.h>
#include <D2D1.h>
#include <wincodec.h>
#include <wincodecsdk.h>

//�֐��v���g�^�C�v�錾
namespace WICHLP{
	HRESULT InitWIC();
	void LoadWICBitmap(
		TCHAR *filename,
		IWICBitmapSource **decorder);
	HRESULT ConvertD2DBitmap(
			IWICBitmapSource *decorder,
			ID2D1RenderTarget *target, ID2D1Bitmap **bitmap);
	void ExitWIC();
}
#endif
