#ifndef __LB_VECTORUITL_H_
#define __LB_VECTORUITL_H_
#include <windows.h>
#include <tchar.h>
#include <D2d1.h>

void RotateVector(float*,float*,float);
float DotProduct(float v1x, float v1y, 
				 float v2x, float v2y);
float CrossProduct(float v1x, float v1y, 
				 float v2x, float v2y);
void AddVector(float v1x, float v1y,
			   float v2x, float v2y,
			   float *rx, float *ry);
void SubVector(float v1x, float v1y,
			   float v2x, float v2y,
			   float *rx, float *ry);
#endif