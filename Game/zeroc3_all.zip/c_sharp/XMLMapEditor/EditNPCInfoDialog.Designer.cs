﻿namespace XMLMapEditor
{
    partial class EditNPCInfoDialog
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.pict_chara = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_NPCname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.list_NPCtype = new System.Windows.Forms.ComboBox();
            this.dg_speech = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.num_monseterid = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_OK = new System.Windows.Forms.Button();
            this.btn_addSpeech = new System.Windows.Forms.Button();
            this.btn_deleteSpeech = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pict_chara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_speech)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_monseterid)).BeginInit();
            this.SuspendLayout();
            // 
            // pict_chara
            // 
            this.pict_chara.Location = new System.Drawing.Point(12, 12);
            this.pict_chara.Name = "pict_chara";
            this.pict_chara.Size = new System.Drawing.Size(48, 48);
            this.pict_chara.TabIndex = 0;
            this.pict_chara.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "名前";
            // 
            // tb_NPCname
            // 
            this.tb_NPCname.Location = new System.Drawing.Point(145, 9);
            this.tb_NPCname.Name = "tb_NPCname";
            this.tb_NPCname.Size = new System.Drawing.Size(121, 19);
            this.tb_NPCname.TabIndex = 2;
            this.tb_NPCname.TextChanged += new System.EventHandler(this.tb_NPCname_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "タイプ";
            // 
            // list_NPCtype
            // 
            this.list_NPCtype.FormattingEnabled = true;
            this.list_NPCtype.Items.AddRange(new object[] {
            "NPC_FREIND",
            "NPC_ENEMY"});
            this.list_NPCtype.Location = new System.Drawing.Point(145, 34);
            this.list_NPCtype.Name = "list_NPCtype";
            this.list_NPCtype.Size = new System.Drawing.Size(121, 20);
            this.list_NPCtype.TabIndex = 4;
            this.list_NPCtype.SelectedIndexChanged += new System.EventHandler(this.list_NPCtype_SelectedIndexChanged);
            // 
            // dg_speech
            // 
            this.dg_speech.AllowUserToAddRows = false;
            this.dg_speech.AllowUserToDeleteRows = false;
            this.dg_speech.AllowUserToResizeRows = false;
            this.dg_speech.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dg_speech.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dg_speech.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_speech.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dg_speech.Location = new System.Drawing.Point(13, 112);
            this.dg_speech.Name = "dg_speech";
            this.dg_speech.RowTemplate.Height = 21;
            this.dg_speech.Size = new System.Drawing.Size(535, 161);
            this.dg_speech.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(76, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "モンスターID";
            // 
            // num_monseterid
            // 
            this.num_monseterid.Location = new System.Drawing.Point(146, 62);
            this.num_monseterid.Name = "num_monseterid";
            this.num_monseterid.Size = new System.Drawing.Size(120, 19);
            this.num_monseterid.TabIndex = 7;
            this.num_monseterid.ValueChanged += new System.EventHandler(this.num_monseterid_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "会話データ（追加不可）";
            // 
            // btn_OK
            // 
            this.btn_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_OK.Location = new System.Drawing.Point(473, 9);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 9;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // btn_addSpeech
            // 
            this.btn_addSpeech.Location = new System.Drawing.Point(15, 279);
            this.btn_addSpeech.Name = "btn_addSpeech";
            this.btn_addSpeech.Size = new System.Drawing.Size(75, 23);
            this.btn_addSpeech.TabIndex = 10;
            this.btn_addSpeech.Text = "セリフ挿入";
            this.btn_addSpeech.UseVisualStyleBackColor = true;
            this.btn_addSpeech.Click += new System.EventHandler(this.btn_addSpeech_Click);
            // 
            // btn_deleteSpeech
            // 
            this.btn_deleteSpeech.Location = new System.Drawing.Point(96, 279);
            this.btn_deleteSpeech.Name = "btn_deleteSpeech";
            this.btn_deleteSpeech.Size = new System.Drawing.Size(75, 23);
            this.btn_deleteSpeech.TabIndex = 11;
            this.btn_deleteSpeech.Text = "セリフ削除";
            this.btn_deleteSpeech.UseVisualStyleBackColor = true;
            this.btn_deleteSpeech.Click += new System.EventHandler(this.btn_deleteSpeech_Click);
            // 
            // EditNPCInfoDialog
            // 
            this.AcceptButton = this.btn_OK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 314);
            this.ControlBox = false;
            this.Controls.Add(this.btn_deleteSpeech);
            this.Controls.Add(this.btn_addSpeech);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.num_monseterid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dg_speech);
            this.Controls.Add(this.list_NPCtype);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_NPCname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pict_chara);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditNPCInfoDialog";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "NPC情報の編集";
            ((System.ComponentModel.ISupportInitialize)(this.pict_chara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg_speech)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_monseterid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pict_chara;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_NPCname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox list_NPCtype;
        private System.Windows.Forms.DataGridView dg_speech;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown num_monseterid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Button btn_addSpeech;
        private System.Windows.Forms.Button btn_deleteSpeech;
    }
}