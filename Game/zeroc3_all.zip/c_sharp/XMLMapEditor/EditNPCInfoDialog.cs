﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace XMLMapEditor
{
    public partial class EditNPCInfoDialog : Form
    {
        private NpcInfo _npcinfo = new NpcInfo();
        private List<Speech> speeches = new List<Speech>();
        //NPC情報を設定するプロパティ
        public NpcInfo npcInfo {
            set {
                this._npcinfo = value;
                this.tb_NPCname.Text = this._npcinfo.name;
                this.list_NPCtype.SelectedIndex = 
                    this._npcinfo.type == NPCType.NPC_ENEMY ? 1 : 0;
                this.num_monseterid.Value = this._npcinfo.monseterid;
                //会話データをバインディング
                this.speeches = new List<Speech>(this._npcinfo.speeches);
                this.dg_speech.AutoGenerateColumns = true;
                this.dg_speech.DataSource = this.speeches;
                this.dg_speech.AllowUserToAddRows = true;
                this.dg_speech.AllowUserToDeleteRows = true;
            }
        }
        public Image npcImage
        {
            set
            {
                pict_chara.Image = value;
            }
        }

        public EditNPCInfoDialog()
        {
            InitializeComponent();
        }

        //変更反映
        private void tb_NPCname_TextChanged(object sender, EventArgs e)
        {
            this._npcinfo.name = this.tb_NPCname.Text;
        }
        private void list_NPCtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            this._npcinfo.type = 
                list_NPCtype.SelectedIndex == 1 ? NPCType.NPC_ENEMY : NPCType.NPC_FRIEND;
        }
        private void num_monseterid_ValueChanged(object sender, EventArgs e)
        {
            this._npcinfo.monseterid =
                (int)this.num_monseterid.Value;
        }

        //新しい行の追加
        private void btn_addSpeech_Click(object sender, EventArgs e)
        {
            if (this.dg_speech.SelectedRows.Count < 1)
            {   //末尾に挿入
                this.speeches.Add(new Speech());
            }
            else
            {
                int idx = this.dg_speech.SelectedRows[0].Index;
                //選択中の行の位置に挿入
                if (idx >= 0 && idx < this.speeches.Count)
                {
                    this.speeches.Insert(idx, new Speech());
                }
            }
            this.speeches = new List<Speech>(this.speeches);
            this.dg_speech.DataSource = this.speeches;
        }

        //選択したセリフの削除
        private void btn_deleteSpeech_Click(object sender, EventArgs e)
        {
            if (this.dg_speech.SelectedRows.Count > 0)
            {
                int idx = this.dg_speech.SelectedRows[0].Index;
                if (idx >= 0 && idx < this.speeches.Count)
                {
                    this.speeches.RemoveAt(idx);
                }
            }
            this.speeches = new List<Speech>(this.speeches);
            this.dg_speech.DataSource = this.speeches;
        }

        //ダイアログを閉じる
        private void btn_OK_Click(object sender, EventArgs e)
        {
            //セリフを反映
            this._npcinfo.speeches = new List<Speech>(this.speeches);
        }

    }
}
