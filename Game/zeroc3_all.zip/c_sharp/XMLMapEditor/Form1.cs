﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Xml;

namespace XMLMapEditor
{
    public partial class Form1 : Form
    {
        //マップデータを記憶する二次元配列（y, x）
        List<List<MapChip>> m_Map = new List<List<MapChip>>();
        int mapsize_w, mapsize_h;
        int hero_x, hero_y;
        //サイズ変更用プロパティ
        public int mapWidth { get { return this.mapsize_w; } set { this.mapsize_w = value; } }
        public int mapHeight { get { return this.mapsize_h; } set { this.mapsize_h = value; } }

        //チップ定義情報の配列
        List<ChipDefine> chipdef = new List<ChipDefine>();
        //モンスター情報の配列
        List<BattleInfo> monsterinfo = new List<BattleInfo>();
        //保存フラグ
        bool issaved = true;
        string filepath;

        public Form1()
        {
            InitializeComponent();
            this.pictMapView.MouseDown += new MouseEventHandler(this.pictMaqView_MouseDown);
            this.splitContainer1.SplitterDistance = 64;
            this.btnNew_Click(this.btnNew, null);
        }

        //マップをイメージに描画
        public void drawMap(){
            //データを読み込み済みか確認
            if (this.chipdef.Count < 1) return;
            if (this.m_Map.Count < 1) return;
            this.pictMapView.Image = 
                new Bitmap(this.mapsize_w * 48, this.mapsize_h * 48);
            using(Graphics g = Graphics.FromImage(this.pictMapView.Image))
            {
                for (int y = 0; y < this.mapsize_h; y++)
                {
                    for (int x = 0; x < this.mapsize_w; x++)
                    {
                        MapChip chip = this.m_Map[y][x];
                        g.DrawImage(this.imageListMapChip.Images[chip.imageid],
                            x * 48, y * 48);
                        //主人公の位置を表す円
                        if (x == this.hero_x && y == this.hero_y)
                        {
                            if (this.imageListChara.Images.Count > 0)
                            {
                                g.DrawImage(this.imageListChara.Images[0],
                                    x * 48, y * 48);
                            }
                            else
                            {
                                Brush brush = new SolidBrush(Color.FromArgb(128, 255, 255, 255));
                                g.FillEllipse(brush, x * 48, y * 48, 48, 48);
                            }
                        }
                        //npcの描画
                        if (chip.npc != null)
                        {
                            if (this.imageListChara.Images.Count > 0)
                            {
                                g.DrawImage(this.imageListChara.Images[chip.npc.imageid],
                                    x * 48, y * 48);
                            }
                            else
                            {
                                Brush brush = new SolidBrush(Color.FromArgb(128, 255, 0, 0));
                                g.FillEllipse(brush, x * 48, y * 48, 48, 48);
                            }
                        }
                    }
                }
            }
        }

        //マップ画像読み込み
        private void btnMapImage_Click(object sender, EventArgs e)
        {
            if (this.openImgFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (Stream imgstream = this.openImgFileDialog.OpenFile())
                {
                    Image mapimg = Image.FromStream(imgstream);
                    int w = mapimg.Width / 48;  //数を調べる
                    //イメージリストに画像を追加していく
                    this.imageListMapChip.Images.Clear();
                    this.listViewChip.Items.Clear();
                    this.chipdef.Clear();
                    for (int i = 0; i < w; i++)
                    {
                        Bitmap bmp = new Bitmap(48, 48);
                        Graphics g = Graphics.FromImage(bmp);
                        g.DrawImage(mapimg, new Rectangle(0, 0, 48, 48),
                            i * 48, 0, 48, 48, GraphicsUnit.Pixel);
                        this.imageListMapChip.Images.Add(bmp);
                        this.listViewChip.Items.Add(i.ToString(), i);
                        //ChipDefine配列も確保しておく
                        this.chipdef.Add(new ChipDefine());
                    }
                    this.drawMap();
                }
            }
           
        }

        //マップデータを読み込む
        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (this.chipdef.Count < 1)
            {
                MessageBox.Show(this,"先に画像を読み込んでください");
                return;
            }
            //保存チェック
            if (this.issaved == false)
            {
                if (MessageBox.Show(
                    "保存されていないデータを消去していいですか？", "XMLMapEditor",
                    MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                {
                    return;
                }
            }
            //読み込み実行
            if (this.openXMLFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (Stream xmlstream = this.openXMLFileDialog.OpenFile())
                {
                    XmlDocument pDocument = new XmlDocument();
                    pDocument.PreserveWhitespace = false;
                    try
                    {
                        pDocument.Load(xmlstream);
                        this.m_Map.Clear();
                        //MAPタグを検索
                        XmlNodeList pList = pDocument.SelectNodes("//map");
                        XmlElement pRoot;
                        if (pList.Count > 0) pRoot = (XmlElement)pList.Item(0);
                        else return;
                        //幅と高さ
                        this.mapsize_w = int.Parse(pRoot.GetAttribute("width"));
                        this.mapsize_h = int.Parse(pRoot.GetAttribute("height"));
                        //プレーヤーキャラの初期位置を読み出す
                        this.hero_x = int.Parse(pRoot.GetAttribute("startx"));
                        this.hero_y = int.Parse(pRoot.GetAttribute("starty"));
                        //チップ定義情報を取得
                        pList = pRoot.SelectNodes("//chipdefine");
                        for (int i = 0; i < pList.Count; i++)
                        {
                            XmlElement pDef = (XmlElement)pList.Item(i);
                            int imageid = int.Parse(pDef.GetAttribute("imageid"));
                            if (imageid < this.chipdef.Count)
                            {
                                this.chipdef[imageid].name = pDef.GetAttribute("name");
                                this.chipdef[imageid].isblock = 
                                    pDef.GetAttribute("isblock")=="1" ? true : false;
                            }
                        }
                        //モンスター情報を取得
                        pList = pRoot.SelectNodes("//monsterdefine");
                        for (int i = 0; i < pList.Count; i++)
                        {
                            this.monsterinfo.Add(new BattleInfo());
                        }
                        for (int i = 0; i < pList.Count; i++)
                        {
                            XmlElement pDef = (XmlElement)pList.Item(i);
                            int monsterid = int.Parse(pDef.GetAttribute("monsterid"));
                            if (monsterid < this.chipdef.Count)
                            {
                                this.monsterinfo[monsterid].life =
                                    int.Parse(pDef.GetAttribute("life"));
                                this.monsterinfo[monsterid].attack = 
                                    int.Parse(pDef.GetAttribute("attack"));
                                this.monsterinfo[monsterid].defense =
                                    int.Parse(pDef.GetAttribute("defense"));
                                this.monsterinfo[monsterid].speed =
                                    int.Parse(pDef.GetAttribute("speed"));
                            }
                        }
                        //マップデータを配列にセット
                        pList = pRoot.SelectNodes("line");
                        for (int y = 0; y < this.mapsize_h; y++)
                        {
                            XmlElement pLine = (XmlElement)pList.Item(y);
                            XmlNodeList pChips = pLine.SelectNodes("chip");
                            //新しい行を追加
                            this.m_Map.Add(new List<MapChip>());
                            for (int x = 0; x < this.mapsize_w; x++)
                            {
                                XmlElement pChip = (XmlElement)pChips.Item(x);
                                this.m_Map[y].Add(new MapChip());
                                //マップの画像IDを取り出す
                                this.m_Map[y][x].imageid =
                                    int.Parse(pChip.GetAttribute("imageid"));
                                if (this.chipdef[this.m_Map[y][x].imageid].isblock)
                                {
                                    this.m_Map[y][x].isblock = true;
                                }
                                //NPCのデータを探す
            					XmlNodeList pNPCs = pChip.SelectNodes("npc");
                                if (pNPCs.Count > 0)
                                {
                                    this.m_Map[y][x].npc = new NpcInfo();
                                    XmlElement pNPC = (XmlElement)pNPCs.Item(0);
                                    //画像IDを取得
                                    this.m_Map[y][x].npc.imageid =
                                        int.Parse(pNPC.GetAttribute("imageid"));
                                    //名前を取得
                                    this.m_Map[y][x].npc.name = pNPC.GetAttribute("name");
                                    //タイプを取得
                                    this.m_Map[y][x].npc.type =
                                        pNPC.GetAttribute("type") == "E" ? 
                                        NPCType.NPC_ENEMY : NPCType.NPC_FRIEND;
                                    //モンスターID
                                    string s = pNPC.GetAttribute("monsterid");
                                    if (s.Length > 0) this.m_Map[y][x].npc.monseterid = int.Parse(s); 
                                    //NPCの会話データの取り出し
                                    this.loadSpeech(this.m_Map[y][x].npc,
                                        pNPC.SelectNodes("speech"));
                                }
                            }                            
                        }
                        this.issaved = true;
                        this.filepath = this.openXMLFileDialog.FileName;
                        this.drawMap();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, ex.ToString() + "\n" + ex.Message);
                    }
                }
            }
        }
        //会話データの取り出し（読み込み時に利用する関数）
        void loadSpeech(NpcInfo npc, XmlNodeList pSpeeches)
        {
	        for(int i=0; i<pSpeeches.Count; i++){
		        Speech newspc = new Speech();
		        newspc.flagid = -1; newspc.setflagid = -1;
		        XmlElement pSpeech = (XmlElement)pSpeeches.Item(i);
		        //セリフの読み出し
		        newspc.text = pSpeech.InnerText;
		        //フラグIDの読み出し
		        string v = pSpeech.GetAttribute("flagid");
		        if(v.Length>0){
			        newspc.flagid = int.Parse(v);
			        newspc.state = int.Parse(pSpeech.GetAttribute("state"));
		        }
		        //フラグ設定情報の読み出し
		        XmlNodeList pSets = pSpeech.SelectNodes("setflag");
		        if(pSets.Count > 0){
			        XmlElement pSet = (XmlElement)pSets.Item(0);
			        newspc.setflagid = int.Parse(pSet.GetAttribute("flagid"));
			        newspc.setstate = int.Parse( pSet.GetAttribute("state"));
		        }
		        //newspcを記憶
		        npc.speeches.Add(newspc);
	        }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            //保存チェック
            if (this.issaved == false)
            {
                if (MessageBox.Show(
                    "保存されていないデータを消去していいですか？", "XMLMapEditor",
                    MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                {
                    return;
                }
            }
            this.m_Map.Clear();
            this.pictMapView.Image = null;
            this.issaved = true;
            this.filepath = "";
            //初期マップ
            this.mapsize_w = 10; this.mapsize_h = 10;
            for (int y = 0; y < this.mapsize_h; y++)
            {
                this.m_Map.Add(new List<MapChip>());
                for (int x = 0; x < this.mapsize_w; x++)
                {
                    this.m_Map[y].Add(new MapChip());
                }
            }
            this.drawMap();
        }

        private void btnCharaImage_Click(object sender, EventArgs e)
        {
            if (this.openImgFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (Stream imgstream = this.openImgFileDialog.OpenFile())
                {
                    Image charaimg = Image.FromStream(imgstream);
                    int w = charaimg.Width / 48;  //数を調べる
                    //イメージリストに画像を追加していく
                    this.imageListChara.Images.Clear();
                    this.listViewChara.Items.Clear();
                    for (int i = 0; i < w; i++)
                    {
                        Bitmap bmp = new Bitmap(48, 48);
                        Graphics g = Graphics.FromImage(bmp);
                        g.DrawImage(charaimg, new Rectangle(0, 0, 48, 48),
                            i * 48, 0, 48, 48, GraphicsUnit.Pixel);
                        this.imageListChara.Images.Add(bmp);
                        this.listViewChara.Items.Add(i.ToString(), i);
                    }
                    this.drawMap();
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            saveXMLFileDialog.FileName = this.filepath;
            if (saveXMLFileDialog.ShowDialog() == DialogResult.OK)
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Encoding = new UTF8Encoding(false);
                settings.Indent = true;
                using (Stream stream = saveXMLFileDialog.OpenFile())
                {
                    using (XmlWriter writer = XmlWriter.Create(stream, settings))
                    {
                        writer.WriteStartDocument();
                        writer.WriteStartElement("map");
                        writer.WriteAttributeString("width", this.mapsize_w.ToString());
                        writer.WriteAttributeString("height", this.mapsize_h.ToString());
                        writer.WriteAttributeString("startx", this.hero_x.ToString());
                        writer.WriteAttributeString("starty", this.hero_y.ToString());
                        //チップ定義の書き出し
                        writer.WriteComment("チップの初期定義");
                        for(int i=0; i<this.chipdef.Count; i++){
                            writer.WriteStartElement("chipdefine");
                            writer.WriteAttributeString("imageid", i.ToString());
                            if (this.chipdef[i].name.Length > 0)
                            {
                                writer.WriteAttributeString("name", this.chipdef[i].name);
                            }
                            writer.WriteAttributeString("isblock",
                                this.chipdef[i].isblock==true ? "1" : "0");
                            writer.WriteEndElement();   //chipdefineを閉じる
                        }
                        //モンスター情報の書き出し
                        writer.WriteComment("モンスターのデータ");
                        for (int i = 0; i < this.monsterinfo.Count; i++)
                        {
                            writer.WriteStartElement("monsterdefine");
                            writer.WriteAttributeString("monsterid", i.ToString());
                            writer.WriteAttributeString("life",
                                this.monsterinfo[i].life.ToString());
                            writer.WriteAttributeString("attack",
                                this.monsterinfo[i].attack.ToString());
                            writer.WriteAttributeString("defense",
                                this.monsterinfo[i].defense.ToString());
                            writer.WriteAttributeString("speed",
                                this.monsterinfo[i].speed.ToString());
                            writer.WriteEndElement();   //monseterdefineを閉じる
                        }

                        //マップデータ書き出し
                        for (int y = 0; y < this.mapsize_h; y++)
                        {
                            writer.WriteStartElement("line");
                            writer.WriteAttributeString("id", y.ToString());
                            for (int x = 0; x < this.mapsize_w; x++)
                            {
                                MapChip chip = this.m_Map[y][x];
                                writer.WriteStartElement("chip");
                                writer.WriteAttributeString("imageid", 
                                    chip.imageid.ToString());
                                //npcデータ書き出し
                                if (chip.npc != null)
                                {
                                    writer.WriteStartElement("npc");
                                    writer.WriteAttributeString("imageid",
                                        chip.npc.imageid.ToString());
                                    writer.WriteAttributeString("name",
                                        chip.npc.name);
                                    writer.WriteAttributeString("type",
                                        chip.npc.type == NPCType.NPC_ENEMY ? "E" : "F");
                                    if (chip.npc.type == NPCType.NPC_ENEMY)
                                    {   //敵ならモンスターIDの書き出し
                                        writer.WriteAttributeString("monsterid",
                                            chip.npc.monseterid.ToString());
                                    }
                                    //セリフ書き出し
                                    for (int i = 0; i < chip.npc.speeches.Count; i++)
                                    {
                                        writer.WriteStartElement("speech");
                                        //フラグ書き出し
                                        if (chip.npc.speeches[i].flagid > -1)
                                        {
                                            writer.WriteAttributeString("flagid",
                                                chip.npc.speeches[i].flagid.ToString());
                                            writer.WriteAttributeString("state",
                                                chip.npc.speeches[i].state.ToString());
                                        }
                                        //セリフ本文
                                        writer.WriteString(chip.npc.speeches[i].text);
                                        //フラグ設定タグの書き出し
                                        if (chip.npc.speeches[i].setflagid > -1)
                                        {
                                            writer.WriteStartElement("setflag");
                                            writer.WriteAttributeString("flagid",
                                                chip.npc.speeches[i].setflagid.ToString());
                                            writer.WriteAttributeString("state",
                                                chip.npc.speeches[i].setstate.ToString());
                                            writer.WriteEndElement();   //setflagを閉じる
                                        }
                                        writer.WriteEndElement();   //speechを閉じる
                                    }
                                    writer.WriteEndElement();   //npcを閉じる
                                }
                                writer.WriteEndElement();   //chipを閉じる
                            }
                            writer.WriteEndElement();   //lineを閉じる
                        }

                        writer.WriteEndElement();   //mapを閉じる
                        writer.Flush();
                        this.filepath = this.saveXMLFileDialog.FileName;
                        this.issaved = true;
                    }

                }
            }
        }

        private Point pos_rightclick;   //右クリックされた位置を記録
        //地図の描画
        private void pictMaqView_MouseDown(object sender, MouseEventArgs e)
        {
            //操作可能か確認
            if (this.mapsize_w < 1 || this.mapsize_h < 1) return;
            if (this.m_Map.Count < 1) return;
            if (this.chipdef.Count < 1) return;
            //左クリックを確認
            if (e.Button == MouseButtons.Left)
            {
                if (this.listViewChip.SelectedIndices.Count > 0)
                {
                    //クリックした位置のマップチップを変更
                    int x = e.X / 48;
                    int y = e.Y / 48;
                    int c = this.listViewChip.SelectedIndices[0];
                    this.m_Map[y][x].imageid = c;
                    using (Graphics g = Graphics.FromImage(this.pictMapView.Image))
                    {
                        g.DrawImage(this.imageListMapChip.Images[c],
                            x * 48, y * 48);
                        if (this.m_Map[y][x].npc != null)
                        {
                            g.DrawImage(this.imageListChara.Images
                                [this.m_Map[y][x].npc.imageid],
                                x * 48, y * 48);

                        }
                    }
                    this.issaved = false;   //保存フラグオフ
                    this.pictMapView.Refresh();
                }
            }
            else if (e.Button == MouseButtons.Right)
            {
                //右クリックでの操作のために位置を記録
                this.pos_rightclick.X = e.X;
                this.pos_rightclick.Y = e.Y;
            }
        }

        //マップサイズの変更
        private void btnSizeChange_Click(object sender, EventArgs e)
        {
            SetSizeDialogbox sizebox = new SetSizeDialogbox();
            sizebox.mapWidth = this.mapsize_w;
            sizebox.mapHeight = this.mapsize_h;
            DialogResult result = sizebox.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                //縮小されるときは確認
                if (this.mapsize_w < this.m_Map[0].Count
                    || this.mapsize_h < this.m_Map.Count)
                {
                    if (MessageBox.Show("縮小するとデータが切り捨てられますがよろしいですか？",
                        "マップサイズ変更", MessageBoxButtons.OKCancel) != DialogResult.OK)
                    {
                        //サイズを戻す
                        this.mapsize_w = this.m_Map[0].Count;
                        this.mapsize_h = this.m_Map.Count;
                        return;
                    }
                }
                //新しいマップサイズに変更
                List<List<MapChip>> newlist = new List<List<MapChip>>();
                for (int y = 0; y < this.mapsize_h; y++)
                {
                    newlist.Add(new List<MapChip>());
                    for (int x = 0; x < this.mapsize_w; x++)
                    {
                        newlist[y].Add(new MapChip());
                        if (y < this.m_Map.Count)
                        {
                            if (x < this.m_Map[y].Count)
                            {
                                newlist[y][x] = this.m_Map[y][x];
                            }
                        }
                    }
                }
                this.m_Map = newlist;
                this.drawMap();
                this.issaved = false;
            }
        }

        //NPCの配置（すでに配置済みの場合は画像のみ変更する）
        private void menu_putNPC_Click(object sender, EventArgs e)
        {
            if (this.listViewChara.SelectedIndices.Count > 0)
            {
                //クリックした位置のマップチップを変更
                int x = this.pos_rightclick.X / 48;
                int y = this.pos_rightclick.Y / 48;
                int c = this.listViewChara.SelectedIndices[0];
                MapChip chip = this.m_Map[y][x];
                if (chip.npc == null) chip.npc = new NpcInfo();
                chip.npc.imageid = c;
                using (Graphics g = Graphics.FromImage(this.pictMapView.Image))
                {
                    g.DrawImage(this.imageListMapChip.Images[chip.imageid],
                        x * 48, y * 48);
                    g.DrawImage(this.imageListChara.Images[chip.npc.imageid],
                        x * 48, y * 48);
                }
                this.issaved = false;   //保存フラグオフ
                this.pictMapView.Refresh();
                this.issaved = false;
            }
        }

        //NPCの削除
        private void move_delNPC_Click(object sender, EventArgs e)
        {
            int x = this.pos_rightclick.X / 48;
            int y = this.pos_rightclick.Y / 48;
            if (this.m_Map[y][x].npc == null) return;
            if (MessageBox.Show("NPCを削除してもいいですか？",
                "マップエディタ", MessageBoxButtons.OKCancel) != DialogResult.OK)
            {
                return;
            }
            this.m_Map[y][x].npc = null;
            this.drawMap();
            this.issaved = false;
        }

        private void menu_setHero_Click(object sender, EventArgs e)
        {
            //配置されたものが0番（主人公）なら初期出現位置変更
            int x = this.pos_rightclick.X / 48;
            int y = this.pos_rightclick.Y / 48;
            this.hero_x = x; 
            this.hero_y = y;
            this.drawMap();
            this.issaved = false;
        }

        //NPC情報の編集
        private void menu_editNPCInfo_Click(object sender, EventArgs e)
        {
            int x = this.pos_rightclick.X / 48;
            int y = this.pos_rightclick.Y / 48;
            if (this.m_Map[y][x].npc == null) return;
            EditNPCInfoDialog npcedit = new EditNPCInfoDialog();
            npcedit.npcInfo = this.m_Map[y][x].npc;
            if (this.imageListChara.Images.Count > 0)
            {
                npcedit.npcImage =
                    this.imageListChara.Images[this.m_Map[y][x].npc.imageid];
            }
            npcedit.ShowDialog(this);
            this.issaved = false;
        }

    }

    public class Speech
    {
        //セリフデータ
        public string text = "";
        //このセリフが表示される条件
        public int flagid = -1;			//フラグID（-1のときは条件なし）
        public int state = 0;			//フラグがこの値のときに表示
        public int setflagid = -1;		//この会話によって設定されるフラグ（-1のときはなし）
        public int setstate = 0;

        public string text_p { get { return this.text; } set { this.text = value; } }
        public int flagid_p { get { return this.flagid; } set { this.flagid = value; } }
        public int state_p { get { return this.state; } set { this.state = value; } }
        public int setflagid_p { get { return this.setflagid; } set { this.setflagid = value; } }
        public int setstate_p { get { return this.setstate; } set { this.setstate = value; } }
    }
    public class NpcInfo
    {
        public int imageid = 0;
        public string name = "";		//名前
        public List<Speech> speeches = new List<Speech>();	//会話データ
        public NPCType type = NPCType.NPC_FRIEND;
        public int monseterid = 0;  //NPC_ENEMYのときのみ有効
    }
    public class MapChip
    {
        public int imageid = 0;
        public NpcInfo npc = null;	//マップ上のキャラクター
        public bool isblock = false;	//通り抜け可能か
    }
    public class ChipDefine
    {
        public string name = "";
        public bool isblock = false;
    }
    public enum NPCType
    {
        NPC_FRIEND, NPC_ENEMY
    }
    public class BattleInfo
    {
        public int life;		//生命力
        public int attack;		//攻撃力
        public int defense;	    //防御力
        public int speed;		//速度
    }
}
