﻿namespace XMLMapEditor
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnNew = new System.Windows.Forms.ToolStripButton();
            this.btnOpen = new System.Windows.Forms.ToolStripButton();
            this.btnSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnMapImage = new System.Windows.Forms.ToolStripButton();
            this.btnCharaImage = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSizeChange = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.listViewChip = new System.Windows.Forms.ListView();
            this.imageListMapChip = new System.Windows.Forms.ImageList(this.components);
            this.listViewChara = new System.Windows.Forms.ListView();
            this.imageListChara = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictMapView = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menu_putNPC = new System.Windows.Forms.ToolStripMenuItem();
            this.move_delNPC = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_setHero = new System.Windows.Forms.ToolStripMenuItem();
            this.openXMLFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveXMLFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.openImgFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.menu_editNPCInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictMapView)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnNew,
            this.btnOpen,
            this.btnSave,
            this.toolStripSeparator2,
            this.btnMapImage,
            this.btnCharaImage,
            this.toolStripSeparator1,
            this.btnSizeChange});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(624, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnNew
            // 
            this.btnNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(60, 22);
            this.btnNew.Text = "新規作成";
            this.btnNew.ToolTipText = "マップデータを新規作成";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(36, 22);
            this.btnOpen.Text = "開く";
            this.btnOpen.ToolTipText = "マップファイルを開く";
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnSave
            // 
            this.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(36, 22);
            this.btnSave.Text = "保存";
            this.btnSave.ToolTipText = "マップファイルを保存";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btnMapImage
            // 
            this.btnMapImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnMapImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMapImage.Name = "btnMapImage";
            this.btnMapImage.Size = new System.Drawing.Size(81, 22);
            this.btnMapImage.Text = "マ画像LOAD";
            this.btnMapImage.Click += new System.EventHandler(this.btnMapImage_Click);
            // 
            // btnCharaImage
            // 
            this.btnCharaImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnCharaImage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCharaImage.Name = "btnCharaImage";
            this.btnCharaImage.Size = new System.Drawing.Size(93, 22);
            this.btnCharaImage.Text = "キャ画像LOAD";
            this.btnCharaImage.ToolTipText = "キャラクター画像を読み込む";
            this.btnCharaImage.Click += new System.EventHandler(this.btnCharaImage_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnSizeChange
            // 
            this.btnSizeChange.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnSizeChange.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSizeChange.Name = "btnSizeChange";
            this.btnSizeChange.Size = new System.Drawing.Size(72, 22);
            this.btnSizeChange.Text = "サイズ変更";
            this.btnSizeChange.Click += new System.EventHandler(this.btnSizeChange_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel1MinSize = 64;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Size = new System.Drawing.Size(624, 417);
            this.splitContainer1.SplitterDistance = 266;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.listViewChip);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.listViewChara);
            this.splitContainer2.Size = new System.Drawing.Size(266, 417);
            this.splitContainer2.SplitterDistance = 190;
            this.splitContainer2.TabIndex = 1;
            // 
            // listViewChip
            // 
            this.listViewChip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listViewChip.LargeImageList = this.imageListMapChip;
            this.listViewChip.Location = new System.Drawing.Point(0, 0);
            this.listViewChip.MinimumSize = new System.Drawing.Size(48, 48);
            this.listViewChip.Name = "listViewChip";
            this.listViewChip.Size = new System.Drawing.Size(266, 190);
            this.listViewChip.SmallImageList = this.imageListMapChip;
            this.listViewChip.TabIndex = 1;
            this.listViewChip.UseCompatibleStateImageBehavior = false;
            this.listViewChip.View = System.Windows.Forms.View.SmallIcon;
            // 
            // imageListMapChip
            // 
            this.imageListMapChip.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
            this.imageListMapChip.ImageSize = new System.Drawing.Size(48, 48);
            this.imageListMapChip.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // listViewChara
            // 
            this.listViewChara.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listViewChara.LargeImageList = this.imageListChara;
            this.listViewChara.Location = new System.Drawing.Point(0, 0);
            this.listViewChara.MinimumSize = new System.Drawing.Size(48, 48);
            this.listViewChara.Name = "listViewChara";
            this.listViewChara.Size = new System.Drawing.Size(266, 223);
            this.listViewChara.SmallImageList = this.imageListChara;
            this.listViewChara.TabIndex = 2;
            this.listViewChara.UseCompatibleStateImageBehavior = false;
            this.listViewChara.View = System.Windows.Forms.View.SmallIcon;
            // 
            // imageListChara
            // 
            this.imageListChara.ColorDepth = System.Windows.Forms.ColorDepth.Depth24Bit;
            this.imageListChara.ImageSize = new System.Drawing.Size(48, 48);
            this.imageListChara.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.pictMapView);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(354, 417);
            this.panel1.TabIndex = 0;
            // 
            // pictMapView
            // 
            this.pictMapView.ContextMenuStrip = this.contextMenuStrip1;
            this.pictMapView.Location = new System.Drawing.Point(0, 0);
            this.pictMapView.Name = "pictMapView";
            this.pictMapView.Size = new System.Drawing.Size(256, 224);
            this.pictMapView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictMapView.TabIndex = 0;
            this.pictMapView.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_putNPC,
            this.move_delNPC,
            this.menu_editNPCInfo,
            this.menu_setHero});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(263, 114);
            // 
            // menu_putNPC
            // 
            this.menu_putNPC.Name = "menu_putNPC";
            this.menu_putNPC.Size = new System.Drawing.Size(262, 22);
            this.menu_putNPC.Text = "NPCの配置(&P)";
            this.menu_putNPC.Click += new System.EventHandler(this.menu_putNPC_Click);
            // 
            // move_delNPC
            // 
            this.move_delNPC.Name = "move_delNPC";
            this.move_delNPC.Size = new System.Drawing.Size(262, 22);
            this.move_delNPC.Text = "NPCの削除(&D)";
            this.move_delNPC.Click += new System.EventHandler(this.move_delNPC_Click);
            // 
            // menu_setHero
            // 
            this.menu_setHero.Name = "menu_setHero";
            this.menu_setHero.Size = new System.Drawing.Size(262, 22);
            this.menu_setHero.Text = "ここを主人公の出現位置にする(&S)";
            this.menu_setHero.Click += new System.EventHandler(this.menu_setHero_Click);
            // 
            // openXMLFileDialog
            // 
            this.openXMLFileDialog.FileName = "map.xml";
            this.openXMLFileDialog.Filter = "XML|*.xml|すべてのファイル|*.*";
            this.openXMLFileDialog.SupportMultiDottedExtensions = true;
            // 
            // saveXMLFileDialog
            // 
            this.saveXMLFileDialog.Filter = "XML|*.xml|すべてのファイル|*.*";
            this.saveXMLFileDialog.SupportMultiDottedExtensions = true;
            // 
            // openImgFileDialog
            // 
            this.openImgFileDialog.FileName = "map.png";
            this.openImgFileDialog.Filter = "PNGファイル|*.png|すべてのファイル|*.*";
            this.openImgFileDialog.SupportMultiDottedExtensions = true;
            // 
            // menu_editNPCInfo
            // 
            this.menu_editNPCInfo.Name = "menu_editNPCInfo";
            this.menu_editNPCInfo.Size = new System.Drawing.Size(262, 22);
            this.menu_editNPCInfo.Text = "NPC情報の編集(&E)";
            this.menu_editNPCInfo.Click += new System.EventHandler(this.menu_editNPCInfo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 442);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Form1";
            this.Text = "XMLMapEditor";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictMapView)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnNew;
        private System.Windows.Forms.ToolStripButton btnOpen;
        private System.Windows.Forms.ToolStripButton btnSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.OpenFileDialog openXMLFileDialog;
        private System.Windows.Forms.SaveFileDialog saveXMLFileDialog;
        private System.Windows.Forms.ImageList imageListMapChip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btnMapImage;
        private System.Windows.Forms.OpenFileDialog openImgFileDialog;
        private System.Windows.Forms.ToolStripButton btnSizeChange;
        private System.Windows.Forms.ToolStripButton btnCharaImage;
        private System.Windows.Forms.ImageList imageListChara;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictMapView;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ListView listViewChip;
        private System.Windows.Forms.ListView listViewChara;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menu_putNPC;
        private System.Windows.Forms.ToolStripMenuItem move_delNPC;
        private System.Windows.Forms.ToolStripMenuItem menu_setHero;
        private System.Windows.Forms.ToolStripMenuItem menu_editNPCInfo;
    }
}

