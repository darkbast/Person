Class.create("Game_MenuGenerated", {

	

}).extend("Game_Plugin");