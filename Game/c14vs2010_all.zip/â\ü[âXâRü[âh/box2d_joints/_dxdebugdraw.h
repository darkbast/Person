//DX���C�u�����p��Box2D�̃f�o�b�O�h���[

#include "DxLib.h"

#include <Box2D/Box2D.h>
#ifdef _DEBUG
	#pragma comment(lib, "Box2D_d.lib")
#endif
#ifndef _DEBUG
	#pragma comment(lib, "Box2D.lib")
#endif

class DxDebugDraw :public b2DebugDraw{
private:
	b2Vec2 screen_pos;
	float WLDSC;
	inline int ColorValue(b2Color col){
		return (int)(col.r * 0xFF0000 + col.g * 0xFF00 + col.b * 0xFF);
	}
	inline int VIWX(float32 x){
		return (int)(x * WLDSC - screen_pos.x);
	}
	inline int VIWY(float32 y){
		return (int)(y * WLDSC - screen_pos.y);
	}
	inline int VIW(float32 v){
		return (int)(v * WLDSC);
	}
public:
	DxDebugDraw(float wldsc){WLDSC = wldsc;}
	void DrawPolygon (const b2Vec2 *vertices, int32 vertexCount, const b2Color &color);
	//�������ʓ|�Ȃ̂�DrawPolygon�փo�C�p�X
	void DrawSolidPolygon (const b2Vec2 *vertices, int32 vertexCount, const b2Color &color);
	void DrawCircle (const b2Vec2 &center, float32 radius, const b2Color &color);
	void DrawSolidCircle (const b2Vec2 &center, float32 radius, const b2Vec2 &axis, const b2Color &color);
	void DrawSegment (const b2Vec2 &p1, const b2Vec2 &p2, const b2Color &color);
	//�ό`�s��̐ݒ�
	void DrawTransform (const b2Transform &xf);
};