//DX���C�u�����p��Box2D�̃f�o�b�O�h���[

#include "_dxdebugdraw.h"

void DxDebugDraw::DrawPolygon (const b2Vec2 *vertices, int32 vertexCount, const b2Color &color){
	if(vertexCount < 2) return;
	int col = ColorValue(color);
	for(int i=0; i<vertexCount - 1; i++){
		DxLib::DrawLine( VIWX(vertices[i].x), VIWY(vertices[i].y),
			VIWX(vertices[i+1].x), VIWY(vertices[i+1].y), col, 2);
	}
	if(vertexCount > 1){
		DxLib::DrawLine( VIWX(vertices[vertexCount-1].x), VIWY(vertices[vertexCount-1].y),
			VIWX(vertices[0].x), VIWY(vertices[0].y), col, 2);
	}
}
//�������ʓ|�Ȃ̂�DrawPolygon�փo�C�p�X
void DxDebugDraw::DrawSolidPolygon (const b2Vec2 *vertices, int32 vertexCount, const b2Color &color){
	DrawPolygon(vertices, vertexCount, color);
}
void DxDebugDraw::DrawCircle (const b2Vec2 &center, float32 radius, const b2Color &color){
	DxLib::DrawCircle(VIWX(center.x), VIWY(center.y), 
		VIW(radius), ColorValue(color), FALSE);
}
void DxDebugDraw::DrawSolidCircle (const b2Vec2 &center, float32 radius, const b2Vec2 &axis, const b2Color &color){
	DxLib::DrawCircle(VIWX(center.x), VIWY(center.y), 
		VIW(radius), ColorValue(color), TRUE);
}
void DxDebugDraw::DrawSegment (const b2Vec2 &p1, const b2Vec2 &p2, const b2Color &color){
	DxLib::DrawLine(VIWX(p1.x), VIWY(p1.y), VIWX(p2.x), VIWY(p2.y), 
		ColorValue(color), 2);
}
//�ό`�s��̐ݒ�i�ʓ|�Ȃ̂Ŏ������Ȃ��j
void DxDebugDraw::DrawTransform (const b2Transform &xf){
	this->screen_pos = xf.position;
}
