﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Xml;

namespace MapEditorForC14
{
    public partial class Form1 : Form
    {
        //マップデータを記録する配列
        List<Character> mapobj = new List<Character>();
        //動的オブジェクトを記録する配列
        List<Character> chrobj = new List<Character>();
        //ヒーローオブジェクト
        Character heroobj = new Character();
        //サイズ変更用プロパティ
        int mapsize_w, mapsize_h;
        public int mapWidth { get { return this.mapsize_w; } set { this.mapsize_w = value; } }
        public int mapHeight { get { return this.mapsize_h; } set { this.mapsize_h = value; } }
        //グリッド値
        const int GRIDSIZE = 24;
        //選択中
        private Character selected_chr = null;
        //フォント
        private Font sfont = new Font(FontFamily.GenericSansSerif, 10);
        //表示倍率
        private float zoomrate = 0.5f;

        //保存フラグ
        bool issaved = true;
        string filepath, txtfilepath;

        public Form1()
        {
            InitializeComponent();
            this.pict_MapView.MouseDown += new MouseEventHandler(this.pictMapView_MouseDown);
            this.KeyDown += new KeyEventHandler(this.Form1_KeyDown);
            this.btn_New_Click(this.btn_New, null);
        }
        //ショートカットキー
        private bool isshiftkey;
        private void Form1_KeyDown(Object sender, KeyEventArgs e)
        {
            this.isshiftkey = e.Shift;
            if (e.Control == true)
            {
                switch (e.KeyCode)
                {
                    case Keys.Down:
                        this.btn_Down48_Click(null, null);
                        break;
                    case Keys.Up:
                        this.btn_Up48_Click(null, null);
                        break;
                    case Keys.Left:
                        this.btn_Left48_Click(null, null);
                        break;
                    case Keys.Right:
                        this.btn_Right48_Click(null, null);
                        break;
                    case Keys.Delete:
                        this.btn_ObjDelete_Click(null, null);
                        break;
                    case Keys.R:
                        float r = (float)this.num_Radian.Value;
                        if (r < 1.57f) r = 1.57f;
                        else r = 0;
                        this.num_Radian.Value = (decimal)r;
                        break;
                }
            }
        }

        //マップをイメージに描画
        public void drawMap()
        {
            using (Graphics g = Graphics.FromImage(this.pict_MapView.Image))
            {
                SolidBrush brush = new SolidBrush(Color.Black);
                g.FillRectangle(brush, 0, 0, this.mapsize_w, this.mapsize_h);
                for (int i = 0; i < this.mapobj.Count; i++)
                {
                    this.drawCharacter(g, this.mapobj[i]);
                }
                for (int i = 0; i < this.chrobj.Count; i++)
                {
                    this.drawCharacter(g, this.chrobj[i]);
                }
                //ヒーロー描画
                Pen pen = new Pen(Color.White);
                g.DrawRectangle(pen, this.heroobj.x - 23, this.heroobj.y - 48, 46, 96);
                g.DrawEllipse(pen, this.heroobj.x - 3, this.heroobj.y - 3, 6, 6);
                this.pict_MapView.Refresh();
            }
        }
        //1つのボックスを描画
        public void drawCharacter(Graphics g, Character chr)
        {
            //色変更
            Color col = Color.DarkCyan;
            if (chr.type == CharacterType.DynamicBody) col = Color.OrangeRed;
            if (chr == this.selected_chr) col = Color.Yellow;
            //描画
            Pen pen = new Pen(col);
            SolidBrush brush = new SolidBrush(Color.DarkGray);
            //中心点描画
            g.FillRectangle(brush, chr.x, chr.y, 24, 24);
            brush.Color = col;
            g.FillEllipse(brush, chr.x - 8, chr.y - 8, 16, 16);
            //ID描画
            g.DrawString(chr.ID.ToString(), sfont, brush, chr.x+4, chr.y+4);
            //輪郭描画
            g.TranslateTransform(chr.x, chr.y);
            g.RotateTransform((float)(chr.radian / Math.PI * 180));
            g.TranslateTransform(-chr.x, -chr.y);
            g.DrawRectangle(pen, chr.x - chr.width / 2, chr.y - chr.height / 2,
                chr.width, chr.height);
            g.ResetTransform();
        }

        private Point pos_rightclick;   //右クリックされた位置を記録
        //地図の描画
        private void pictMapView_MouseDown(object sender, MouseEventArgs e)
        {
            //左クリックを確認
            if (e.Button == MouseButtons.Left)
            {
                //クリックした位置のマップチップを変更
                using (Graphics g = Graphics.FromImage(this.pict_MapView.Image))
                {
                    //前の選択オブジェクトを描き直し
                    if (this.selected_chr != null)
                    {
                        Character prechr = this.selected_chr;
                        this.selected_chr = null;
                        this.drawCharacter(g, prechr);
                    }
                    //クリック位置に既存のキャラクターがあるか確認
                    Character retchr = this.HitCheck(e.X, e.Y);
                    if (retchr != null)
                    {
                        //既存のオブジェクトを選択
                        this.selected_chr = retchr;
                        this.drawCharacter(g, this.selected_chr);
                        this.num_Xpos.Value = (decimal)this.selected_chr.x;
                        this.num_Ypos.Value = (decimal)this.selected_chr.y;
                        this.num_Width.Value = (decimal)this.selected_chr.width;
                        this.num_Height.Value = (decimal)this.selected_chr.height;
                        this.num_ID.Value = (decimal)this.selected_chr.ID;
                        this.num_Radian.Value = (decimal)this.selected_chr.radian;
                        //nullでない場合は選択されたことになる
                        if (retchr.type == CharacterType.StaticBody)
                        {
                            //静的オブジェクト
                            this.rbtn_Static.Checked = true;
                        }
                        else
                        {
                            //動的オブジェクト
                            this.rbtn_Dyamic.Checked = true;
                        }

                    }
                    else
                    {
                        //新規追加
                        int x = (e.X / Form1.GRIDSIZE) * Form1.GRIDSIZE;
                        int y = (e.Y / Form1.GRIDSIZE) * Form1.GRIDSIZE;
                        Character newchr = new Character();
                        newchr.x = x;
                        newchr.y = y;
                        this.num_Xpos.Value = x;
                        this.num_Ypos.Value = y;
                        newchr.width = (int)this.num_Width.Value;
                        newchr.height = (int)this.num_Height.Value;
                        newchr.ID = (int)this.num_ID.Value;
                        newchr.radian = (float)this.num_Radian.Value;
                        this.selected_chr = newchr;
                        //新しいオブジェクトを配置
                        if (this.rbtn_Dyamic.Checked)
                        {
                            newchr.type = CharacterType.DynamicBody;
                            this.chrobj.Add(newchr);
                            this.drawCharacter(g, newchr);
                        }
                        else if (this.rbtn_Static.Checked)
                        {
                            newchr.type = CharacterType.StaticBody;
                            this.mapobj.Add(newchr);
                            this.drawCharacter(g, newchr);
                        }
                        else if (this.rbtn_Hero.Checked)
                        {
                            this.selected_chr = null;
                            this.heroobj.x = x;
                            this.heroobj.y = y;
                            this.drawMap();
                        }
                    }
                }
                this.issaved = false;   //保存フラグオフ
                this.pict_MapView.Refresh();
            }
            else if (e.Button == MouseButtons.Right)
            {
                //右クリックでの操作のために位置を記録
                this.pos_rightclick.X = e.X;
                this.pos_rightclick.Y = e.Y;
            }
        }
        //クリックした位置にキャラクターがあるかチェックする
        private Character HitCheck(int cx, int cy)
        {
            for (int i = 0; i < this.chrobj.Count; i++)
            {
                int ox = (int)this.chrobj[i].x;
                int oy = (int)this.chrobj[i].y;
                if (cx >= ox && cy >= oy && cx < ox + 24 && cy < oy + 24)
                {
                    return this.chrobj[i];
                }
            }
            for (int i = 0; i < this.mapobj.Count; i++)
            {
                int ox = (int)this.mapobj[i].x;
                int oy = (int)this.mapobj[i].y;
                if (cx >= ox && cy >= oy && cx < ox + 24 && cy < oy + 24)
                {
                    return this.mapobj[i];
                }
            }
            return null;
        }

        private void btn_New_Click(object sender, EventArgs e)
        {
            //保存チェック
            if (this.issaved == false)
            {
                if (MessageBox.Show(
                    "保存されていないデータを消去していいですか？", "XMLMapEditor",
                    MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                {
                    return;
                }
            }
            this.mapobj.Clear();
            this.chrobj.Clear();
            this.pict_MapView.Image = null;
            this.issaved = true;
            this.filepath = "";
            this.txtfilepath = "";
            //初期マップ
            this.mapsize_w = 640; this.mapsize_h = 480;
            this.pict_MapView.Image = new Bitmap(this.mapsize_w, this.mapsize_h);
            this.drawMap();
        }

        private void btn_Open_Click(object sender, EventArgs e)
        {
            //保存チェック
            if (this.issaved == false)
            {
                if (MessageBox.Show(
                    "保存されていないデータを消去していいですか？", "MapEditor",
                    MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                {
                    return;
                }
            }
            //読み込み実行
            if (this.openXMLFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (Stream xmlstream = this.openXMLFileDialog.OpenFile())
                {
                    XmlDocument pDocument = new XmlDocument();
                    pDocument.PreserveWhitespace = false;
                    try
                    {
                        pDocument.Load(xmlstream);
                        this.mapobj.Clear();
                        this.chrobj.Clear();

                        //ここに読み込み処理を書く
                        //MAPタグを検索
                        XmlNodeList pList = pDocument.SelectNodes("//map");
                        XmlElement pRoot;
                        if (pList.Count > 0) pRoot = (XmlElement)pList.Item(0);
                        else return;
                        //幅と高さ
                        this.mapsize_w = int.Parse(pRoot.GetAttribute("width"));
                        this.mapsize_h = int.Parse(pRoot.GetAttribute("height"));
                        //プレーヤーキャラの初期位置を読み出す
                        this.heroobj.x = int.Parse(pRoot.GetAttribute("startx"));
                        this.heroobj.y = int.Parse(pRoot.GetAttribute("starty"));
                        //静的オブジェクトを取得
                        pList = pRoot.SelectNodes("//mapobjects");
                        XmlElement mapobjroot;
                        if (pList.Count > 0) mapobjroot = (XmlElement)pList.Item(0);
                        else return;
                        pList = mapobjroot.SelectNodes("object");
                        for (int i = 0; i < pList.Count; i++)
                        {
                            Character newchr = new Character();
                            XmlElement pDef = (XmlElement)pList.Item(i);
                            newchr.x = float.Parse(pDef.GetAttribute("x"));
                            newchr.y = float.Parse(pDef.GetAttribute("y"));
                            newchr.width = float.Parse(pDef.GetAttribute("width"));
                            newchr.height = float.Parse(pDef.GetAttribute("height"));
                            newchr.ID = int.Parse(pDef.GetAttribute("ID"));
                            newchr.radian = float.Parse(pDef.GetAttribute("radian"));
                            newchr.type = CharacterType.StaticBody;
                            this.mapobj.Add(newchr);
                        }
                        //動的オブジェクトを取得
                        pList = pRoot.SelectNodes("//charaobjects");
                        XmlElement chrobjroot;
                        if (pList.Count > 0) chrobjroot = (XmlElement)pList.Item(0);
                        else return;
                        pList = chrobjroot.SelectNodes("object");
                        for (int i = 0; i < pList.Count; i++)
                        {
                            Character newchr = new Character();
                            XmlElement pDef = (XmlElement)pList.Item(i);
                            newchr.x = float.Parse(pDef.GetAttribute("x"));
                            newchr.y = float.Parse(pDef.GetAttribute("y"));
                            newchr.width = float.Parse(pDef.GetAttribute("width"));
                            newchr.height = float.Parse(pDef.GetAttribute("height"));
                            newchr.ID = int.Parse(pDef.GetAttribute("ID"));
                            newchr.radian = float.Parse(pDef.GetAttribute("radian"));
                            newchr.type = CharacterType.DynamicBody;
                            this.chrobj.Add(newchr);
                        }

                        this.issaved = true;
                        this.filepath = this.openXMLFileDialog.FileName;
                        this.txtfilepath = "";
                        this.pict_MapView.Image = new Bitmap(this.mapsize_w, this.mapsize_h);
                        this.drawMap();
                        this.pict_MapView.Refresh();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, ex.ToString() + "\n" + ex.Message);
                    }
                }
            }

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            saveXMLFileDialog.FileName = this.filepath;
            if (saveXMLFileDialog.ShowDialog() == DialogResult.OK)
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Encoding = new UTF8Encoding(false);
                settings.Indent = true;
                using (Stream stream = saveXMLFileDialog.OpenFile())
                {
                    using (XmlWriter writer = XmlWriter.Create(stream, settings))
                    {
                        writer.WriteStartDocument();
                        writer.WriteStartElement("map");
                        writer.WriteAttributeString("width", this.mapsize_w.ToString());
                        writer.WriteAttributeString("height", this.mapsize_h.ToString());
                        writer.WriteAttributeString("startx", this.heroobj.x.ToString());
                        writer.WriteAttributeString("starty", this.heroobj.y.ToString());
                        //マップ定義の書き出し
                        writer.WriteComment("静的オブジェクト");
                        writer.WriteStartElement("mapobjects");
                        for(int i=0; i<this.mapobj.Count; i++){
                            writer.WriteStartElement("object");
                            writer.WriteAttributeString("x", this.mapobj[i].x.ToString());
                            writer.WriteAttributeString("y", this.mapobj[i].y.ToString());
                            writer.WriteAttributeString("width", this.mapobj[i].width.ToString());
                            writer.WriteAttributeString("height", this.mapobj[i].height.ToString());
                            writer.WriteAttributeString("radian", this.mapobj[i].radian.ToString());
                            writer.WriteAttributeString("ID", this.mapobj[i].ID.ToString());
                            writer.WriteEndElement();   //objectを閉じる
                        }
                        writer.WriteFullEndElement();   //mapobjectsを閉じる
                        //動的オブジェクト定義の書き出し
                        writer.WriteComment("動的オブジェクト");
                        writer.WriteStartElement("charaobjects");
                        for(int i=0; i<this.chrobj.Count; i++){
                            writer.WriteStartElement("object");
                            writer.WriteAttributeString("x", this.chrobj[i].x.ToString());
                            writer.WriteAttributeString("y", this.chrobj[i].y.ToString());
                            writer.WriteAttributeString("width", this.chrobj[i].width.ToString());
                            writer.WriteAttributeString("height", this.chrobj[i].height.ToString());
                            writer.WriteAttributeString("radian", this.chrobj[i].radian.ToString());
                            writer.WriteAttributeString("ID", this.chrobj[i].ID.ToString());
                            writer.WriteEndElement();   //objectを閉じる
                        }
                        writer.WriteFullEndElement();   //charaobjectsを閉じる
                        writer.WriteEndElement();   //mapを閉じる
                        writer.Flush();
                        this.filepath = this.saveXMLFileDialog.FileName;
                        this.issaved = true;
                    }

                }
            }

        }
        //テキストファイルとして書き出し
        private void btn_TXTOutput_Click(object sender, EventArgs e)
        {
            outputTXTFileDialog.FileName = this.txtfilepath;
            if (outputTXTFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (Stream stream = outputTXTFileDialog.OpenFile())
                {
                    StreamWriter strwriter = new StreamWriter(stream);
                    strwriter.WriteLine(this.mapsize_w + ", " + this.mapsize_h + ", " +
                        this.heroobj.x +", " + this.heroobj.y );
                    strwriter.WriteLine(this.mapobj.Count);
                    for (int i = 0; i < this.mapobj.Count; i++)
                    {
                        strwriter.WriteLine(this.mapobj[i].x + ", " + this.mapobj[i].y + ", " +
                            this.mapobj[i].width + ", " + this.mapobj[i].height + ", " +
                            this.mapobj[i].radian + ", " + this.mapobj[i].ID);
                    }
                    strwriter.WriteLine(this.chrobj.Count);
                    for (int i = 0; i < this.chrobj.Count; i++)
                    {
                        strwriter.WriteLine(this.chrobj[i].x + ", " + this.chrobj[i].y + ", " +
                            this.chrobj[i].width + ", " + this.chrobj[i].height + ", " +
                            this.chrobj[i].radian + ", " + this.chrobj[i].ID);
                    }
                    strwriter.Flush();
                    this.txtfilepath = this.outputTXTFileDialog.FileName;
                }
            }
        }

        //マップサイズ変更
        private void btn_MapSize_Click(object sender, EventArgs e)
        {
            MapSizeForm sizebox = new MapSizeForm();
            sizebox.mapWidth = this.mapsize_w;
            sizebox.mapHeight = this.mapsize_h;
            DialogResult result = sizebox.ShowDialog(this);
            this.pict_MapView.Image = new Bitmap(this.mapsize_w, this.mapsize_h);
            this.drawMap();            
        }

        //値を変更
        private void num_Xpos_ValueChanged(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.x = (float)this.num_Xpos.Value;
                this.drawMap();
            }
        }

        private void num_Ypos_ValueChanged(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.y = (float)this.num_Ypos.Value;
                this.drawMap();
            }
        }

        private void num_Width_ValueChanged(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.width = (float)this.num_Width.Value;
                this.drawMap();
            }
        }

        private void num_Height_ValueChanged(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.height = (float)this.num_Height.Value;
                this.drawMap();
            }
        }

        private void num_Radian_ValueChanged(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.radian = (float)this.num_Radian.Value;
                this.drawMap();
            }
        }

        private void num_ID_ValueChanged(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.ID = (int)this.num_ID.Value;
                this.drawMap();
            }            
        }

        private void btn_Up48_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                int y;
                if (this.isshiftkey)
                {
                    y = (int)(this.selected_chr.y - 1);
                }
                else
                {
                    y = (int)(this.selected_chr.y - 24) / Form1.GRIDSIZE * Form1.GRIDSIZE;
                }
                this.selected_chr.y = y;
                this.num_Ypos.Value = (decimal)y;
                this.drawMap();
            }                        
        }

        private void btn_Down48_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                int y;
                if (this.isshiftkey)
                {
                    y = (int)(this.selected_chr.y + 1);
                }
                else
                {
                    y = (int)(this.selected_chr.y + 24) / Form1.GRIDSIZE * Form1.GRIDSIZE;
                }
                this.selected_chr.y = y;
                this.num_Ypos.Value = (decimal)y;
                this.drawMap();
            }                        
        }

        private void btn_Left48_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                int x;
                if (this.isshiftkey)
                {
                    x = (int)(this.selected_chr.x - 1);
                }
                else
                {
                    x = (int)(this.selected_chr.x - 24) / Form1.GRIDSIZE * Form1.GRIDSIZE;
                }
                this.selected_chr.x = x;
                this.num_Xpos.Value = (decimal)x;
                this.drawMap();
            }                        
        }

        private void btn_Right48_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                int x;
                if (this.isshiftkey)
                {
                    x = (int)(this.selected_chr.x + 1);
                }
                else
                {
                    x = (int)(this.selected_chr.x + 24) / Form1.GRIDSIZE * Form1.GRIDSIZE;
                }
                this.selected_chr.x = x;
                this.num_Xpos.Value = (decimal)x;
                this.drawMap();
            }                        
        }

        private void btn_wide48_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.width = 48;
                this.num_Width.Value = (decimal)48;
                this.drawMap();
            }                        
        }

        private void btn_wide192_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.width = 192;
                this.num_Width.Value = (decimal)192;
                this.drawMap();
            }                        
        }

        private void btn_wide284_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.width = 284;
                this.num_Width.Value = (decimal)284;
                this.drawMap();
            }                        
        }

        private void btn_wide568_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                this.selected_chr.width = 568;
                this.num_Width.Value = (decimal)568;
                this.drawMap();
            }                        
        }

        //オブジェクト削除
        private void btn_ObjDelete_Click(object sender, EventArgs e)
        {
            if (this.selected_chr != null)
            {
                if (this.selected_chr.type == CharacterType.DynamicBody)
                {
                    this.chrobj.Remove(this.selected_chr);
                }
                else
                {
                    this.mapobj.Remove(this.selected_chr);
                }
                this.selected_chr = null;
                this.drawMap();
            }
        }

    }

    public enum CharacterType { StaticBody, DynamicBody }
    public class Character
    {
        public float x, y, width, height, radian;
        public int ID;
        public CharacterType type;
    }
}
