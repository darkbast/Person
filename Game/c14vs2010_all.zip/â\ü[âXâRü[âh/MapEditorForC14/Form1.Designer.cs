﻿namespace MapEditorForC14
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_New = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btn_Open = new System.Windows.Forms.ToolStripButton();
            this.btn_Save = new System.Windows.Forms.ToolStripButton();
            this.btn_MapSize = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_TXTOutput = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.chk_GridSnap = new System.Windows.Forms.CheckBox();
            this.rbtn_Hero = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.rbtn_Dyamic = new System.Windows.Forms.RadioButton();
            this.rbtn_Static = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_Down48 = new System.Windows.Forms.Button();
            this.btn_Right48 = new System.Windows.Forms.Button();
            this.btn_wide568 = new System.Windows.Forms.Button();
            this.btn_wide284 = new System.Windows.Forms.Button();
            this.btn_wide192 = new System.Windows.Forms.Button();
            this.btn_wide48 = new System.Windows.Forms.Button();
            this.btn_Left48 = new System.Windows.Forms.Button();
            this.btn_Up48 = new System.Windows.Forms.Button();
            this.btn_ObjDelete = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.num_ID = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.num_Height = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.num_Width = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.num_Ypos = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.num_Xpos = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.num_Radian = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.pict_MapView = new System.Windows.Forms.PictureBox();
            this.openXMLFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveXMLFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.outputTXTFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.toolStrip1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ypos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Xpos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Radian)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_MapView)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_New
            // 
            this.btn_New.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btn_New.Image = ((System.Drawing.Image)(resources.GetObject("btn_New.Image")));
            this.btn_New.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_New.Name = "btn_New";
            this.btn_New.Size = new System.Drawing.Size(60, 22);
            this.btn_New.Text = "新規作成";
            this.btn_New.Click += new System.EventHandler(this.btn_New_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_New,
            this.btn_Open,
            this.btn_Save,
            this.btn_MapSize,
            this.toolStripSeparator1,
            this.btn_TXTOutput});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(624, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btn_Open
            // 
            this.btn_Open.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btn_Open.Image = ((System.Drawing.Image)(resources.GetObject("btn_Open.Image")));
            this.btn_Open.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Open.Name = "btn_Open";
            this.btn_Open.Size = new System.Drawing.Size(36, 22);
            this.btn_Open.Text = "開く";
            this.btn_Open.Click += new System.EventHandler(this.btn_Open_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btn_Save.Image = ((System.Drawing.Image)(resources.GetObject("btn_Save.Image")));
            this.btn_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(36, 22);
            this.btn_Save.Text = "保存";
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_MapSize
            // 
            this.btn_MapSize.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btn_MapSize.Image = ((System.Drawing.Image)(resources.GetObject("btn_MapSize.Image")));
            this.btn_MapSize.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_MapSize.Name = "btn_MapSize";
            this.btn_MapSize.Size = new System.Drawing.Size(84, 22);
            this.btn_MapSize.Text = "マップサイズ";
            this.btn_MapSize.Click += new System.EventHandler(this.btn_MapSize_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_TXTOutput
            // 
            this.btn_TXTOutput.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btn_TXTOutput.Image = ((System.Drawing.Image)(resources.GetObject("btn_TXTOutput.Image")));
            this.btn_TXTOutput.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_TXTOutput.Name = "btn_TXTOutput";
            this.btn_TXTOutput.Size = new System.Drawing.Size(84, 22);
            this.btn_TXTOutput.Text = "TXT書き出し";
            this.btn_TXTOutput.Click += new System.EventHandler(this.btn_TXTOutput_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.splitContainer1.Panel2.Controls.Add(this.pict_MapView);
            this.splitContainer1.Size = new System.Drawing.Size(624, 448);
            this.splitContainer1.SplitterDistance = 208;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.chk_GridSnap);
            this.splitContainer3.Panel1.Controls.Add(this.rbtn_Hero);
            this.splitContainer3.Panel1.Controls.Add(this.label1);
            this.splitContainer3.Panel1.Controls.Add(this.rbtn_Dyamic);
            this.splitContainer3.Panel1.Controls.Add(this.rbtn_Static);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer3.Panel2.Controls.Add(this.label8);
            this.splitContainer3.Panel2.Controls.Add(this.num_ID);
            this.splitContainer3.Panel2.Controls.Add(this.label7);
            this.splitContainer3.Panel2.Controls.Add(this.num_Height);
            this.splitContainer3.Panel2.Controls.Add(this.label6);
            this.splitContainer3.Panel2.Controls.Add(this.num_Width);
            this.splitContainer3.Panel2.Controls.Add(this.label5);
            this.splitContainer3.Panel2.Controls.Add(this.num_Ypos);
            this.splitContainer3.Panel2.Controls.Add(this.label4);
            this.splitContainer3.Panel2.Controls.Add(this.num_Xpos);
            this.splitContainer3.Panel2.Controls.Add(this.label3);
            this.splitContainer3.Panel2.Controls.Add(this.num_Radian);
            this.splitContainer3.Panel2.Controls.Add(this.label2);
            this.splitContainer3.Size = new System.Drawing.Size(208, 448);
            this.splitContainer3.SplitterDistance = 108;
            this.splitContainer3.TabIndex = 0;
            // 
            // chk_GridSnap
            // 
            this.chk_GridSnap.AutoSize = true;
            this.chk_GridSnap.Checked = true;
            this.chk_GridSnap.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_GridSnap.Enabled = false;
            this.chk_GridSnap.Location = new System.Drawing.Point(6, 85);
            this.chk_GridSnap.Name = "chk_GridSnap";
            this.chk_GridSnap.Size = new System.Drawing.Size(127, 16);
            this.chk_GridSnap.TabIndex = 4;
            this.chk_GridSnap.Text = "グリッドスナップ（24px）";
            this.chk_GridSnap.UseVisualStyleBackColor = true;
            // 
            // rbtn_Hero
            // 
            this.rbtn_Hero.AutoSize = true;
            this.rbtn_Hero.Location = new System.Drawing.Point(5, 63);
            this.rbtn_Hero.Name = "rbtn_Hero";
            this.rbtn_Hero.Size = new System.Drawing.Size(115, 16);
            this.rbtn_Hero.TabIndex = 3;
            this.rbtn_Hero.TabStop = true;
            this.rbtn_Hero.Text = "主人公（StartPos）";
            this.rbtn_Hero.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "配置するもの";
            // 
            // rbtn_Dyamic
            // 
            this.rbtn_Dyamic.AutoSize = true;
            this.rbtn_Dyamic.Location = new System.Drawing.Point(5, 41);
            this.rbtn_Dyamic.Name = "rbtn_Dyamic";
            this.rbtn_Dyamic.Size = new System.Drawing.Size(59, 16);
            this.rbtn_Dyamic.TabIndex = 2;
            this.rbtn_Dyamic.TabStop = true;
            this.rbtn_Dyamic.Text = "イベント";
            this.rbtn_Dyamic.UseVisualStyleBackColor = true;
            // 
            // rbtn_Static
            // 
            this.rbtn_Static.AutoSize = true;
            this.rbtn_Static.Location = new System.Drawing.Point(6, 19);
            this.rbtn_Static.Name = "rbtn_Static";
            this.rbtn_Static.Size = new System.Drawing.Size(85, 16);
            this.rbtn_Static.TabIndex = 1;
            this.rbtn_Static.TabStop = true;
            this.rbtn_Static.Text = "地形（Body）";
            this.rbtn_Static.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.btn_Down48);
            this.groupBox1.Controls.Add(this.btn_Right48);
            this.groupBox1.Controls.Add(this.btn_wide568);
            this.groupBox1.Controls.Add(this.btn_wide284);
            this.groupBox1.Controls.Add(this.btn_wide192);
            this.groupBox1.Controls.Add(this.btn_wide48);
            this.groupBox1.Controls.Add(this.btn_Left48);
            this.groupBox1.Controls.Add(this.btn_Up48);
            this.groupBox1.Controls.Add(this.btn_ObjDelete);
            this.groupBox1.Location = new System.Drawing.Point(6, 172);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 161);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "コントローラ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 12);
            this.label9.TabIndex = 16;
            this.label9.Text = "幅プリセット";
            // 
            // btn_Down48
            // 
            this.btn_Down48.Location = new System.Drawing.Point(65, 47);
            this.btn_Down48.Name = "btn_Down48";
            this.btn_Down48.Size = new System.Drawing.Size(75, 23);
            this.btn_Down48.TabIndex = 15;
            this.btn_Down48.Text = "下移動(&S)";
            this.btn_Down48.UseVisualStyleBackColor = true;
            this.btn_Down48.Click += new System.EventHandler(this.btn_Down48_Click);
            // 
            // btn_Right48
            // 
            this.btn_Right48.Location = new System.Drawing.Point(141, 47);
            this.btn_Right48.Name = "btn_Right48";
            this.btn_Right48.Size = new System.Drawing.Size(55, 23);
            this.btn_Right48.TabIndex = 15;
            this.btn_Right48.Text = "右(&D)";
            this.btn_Right48.UseVisualStyleBackColor = true;
            this.btn_Right48.Click += new System.EventHandler(this.btn_Right48_Click);
            // 
            // btn_wide568
            // 
            this.btn_wide568.Location = new System.Drawing.Point(150, 103);
            this.btn_wide568.Name = "btn_wide568";
            this.btn_wide568.Size = new System.Drawing.Size(48, 23);
            this.btn_wide568.TabIndex = 15;
            this.btn_wide568.Text = "568W";
            this.btn_wide568.UseVisualStyleBackColor = true;
            this.btn_wide568.Click += new System.EventHandler(this.btn_wide568_Click);
            // 
            // btn_wide284
            // 
            this.btn_wide284.Location = new System.Drawing.Point(102, 103);
            this.btn_wide284.Name = "btn_wide284";
            this.btn_wide284.Size = new System.Drawing.Size(48, 23);
            this.btn_wide284.TabIndex = 15;
            this.btn_wide284.Text = "284W";
            this.btn_wide284.UseVisualStyleBackColor = true;
            this.btn_wide284.Click += new System.EventHandler(this.btn_wide284_Click);
            // 
            // btn_wide192
            // 
            this.btn_wide192.Location = new System.Drawing.Point(54, 103);
            this.btn_wide192.Name = "btn_wide192";
            this.btn_wide192.Size = new System.Drawing.Size(48, 23);
            this.btn_wide192.TabIndex = 15;
            this.btn_wide192.Text = "192W";
            this.btn_wide192.UseVisualStyleBackColor = true;
            this.btn_wide192.Click += new System.EventHandler(this.btn_wide192_Click);
            // 
            // btn_wide48
            // 
            this.btn_wide48.Location = new System.Drawing.Point(6, 103);
            this.btn_wide48.Name = "btn_wide48";
            this.btn_wide48.Size = new System.Drawing.Size(48, 23);
            this.btn_wide48.TabIndex = 15;
            this.btn_wide48.Text = "48W";
            this.btn_wide48.UseVisualStyleBackColor = true;
            this.btn_wide48.Click += new System.EventHandler(this.btn_wide48_Click);
            // 
            // btn_Left48
            // 
            this.btn_Left48.Location = new System.Drawing.Point(6, 47);
            this.btn_Left48.Name = "btn_Left48";
            this.btn_Left48.Size = new System.Drawing.Size(59, 23);
            this.btn_Left48.TabIndex = 15;
            this.btn_Left48.Text = "左(&A)";
            this.btn_Left48.UseVisualStyleBackColor = true;
            this.btn_Left48.Click += new System.EventHandler(this.btn_Left48_Click);
            // 
            // btn_Up48
            // 
            this.btn_Up48.Location = new System.Drawing.Point(65, 18);
            this.btn_Up48.Name = "btn_Up48";
            this.btn_Up48.Size = new System.Drawing.Size(75, 23);
            this.btn_Up48.TabIndex = 15;
            this.btn_Up48.Text = "上移動(&W)";
            this.btn_Up48.UseVisualStyleBackColor = true;
            this.btn_Up48.Click += new System.EventHandler(this.btn_Up48_Click);
            // 
            // btn_ObjDelete
            // 
            this.btn_ObjDelete.Location = new System.Drawing.Point(8, 132);
            this.btn_ObjDelete.Name = "btn_ObjDelete";
            this.btn_ObjDelete.Size = new System.Drawing.Size(75, 23);
            this.btn_ObjDelete.TabIndex = 13;
            this.btn_ObjDelete.Text = "削除(&X)";
            this.btn_ObjDelete.UseVisualStyleBackColor = true;
            this.btn_ObjDelete.Click += new System.EventHandler(this.btn_ObjDelete_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 12);
            this.label8.TabIndex = 12;
            this.label8.Text = "ID";
            // 
            // num_ID
            // 
            this.num_ID.Location = new System.Drawing.Point(85, 147);
            this.num_ID.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.num_ID.Name = "num_ID";
            this.num_ID.Size = new System.Drawing.Size(120, 19);
            this.num_ID.TabIndex = 11;
            this.num_ID.ValueChanged += new System.EventHandler(this.num_ID_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "高さ（px）";
            // 
            // num_Height
            // 
            this.num_Height.Location = new System.Drawing.Point(85, 97);
            this.num_Height.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.num_Height.Name = "num_Height";
            this.num_Height.Size = new System.Drawing.Size(120, 19);
            this.num_Height.TabIndex = 9;
            this.num_Height.Value = new decimal(new int[] {
            48,
            0,
            0,
            0});
            this.num_Height.ValueChanged += new System.EventHandler(this.num_Height_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "幅（px）";
            // 
            // num_Width
            // 
            this.num_Width.Location = new System.Drawing.Point(85, 72);
            this.num_Width.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.num_Width.Name = "num_Width";
            this.num_Width.Size = new System.Drawing.Size(120, 19);
            this.num_Width.TabIndex = 7;
            this.num_Width.Value = new decimal(new int[] {
            48,
            0,
            0,
            0});
            this.num_Width.ValueChanged += new System.EventHandler(this.num_Width_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "Y座標（px）";
            // 
            // num_Ypos
            // 
            this.num_Ypos.Location = new System.Drawing.Point(85, 47);
            this.num_Ypos.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.num_Ypos.Name = "num_Ypos";
            this.num_Ypos.Size = new System.Drawing.Size(120, 19);
            this.num_Ypos.TabIndex = 5;
            this.num_Ypos.ValueChanged += new System.EventHandler(this.num_Ypos_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "X座標（px）";
            // 
            // num_Xpos
            // 
            this.num_Xpos.Location = new System.Drawing.Point(85, 22);
            this.num_Xpos.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.num_Xpos.Name = "num_Xpos";
            this.num_Xpos.Size = new System.Drawing.Size(120, 19);
            this.num_Xpos.TabIndex = 3;
            this.num_Xpos.ValueChanged += new System.EventHandler(this.num_Xpos_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "角度（rad）";
            // 
            // num_Radian
            // 
            this.num_Radian.DecimalPlaces = 3;
            this.num_Radian.Increment = new decimal(new int[] {
            2,
            0,
            0,
            131072});
            this.num_Radian.Location = new System.Drawing.Point(85, 122);
            this.num_Radian.Maximum = new decimal(new int[] {
            314,
            0,
            0,
            131072});
            this.num_Radian.Minimum = new decimal(new int[] {
            314,
            0,
            0,
            -2147352576});
            this.num_Radian.Name = "num_Radian";
            this.num_Radian.Size = new System.Drawing.Size(120, 19);
            this.num_Radian.TabIndex = 10;
            this.num_Radian.ValueChanged += new System.EventHandler(this.num_Radian_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "プロパティ";
            // 
            // pict_MapView
            // 
            this.pict_MapView.Location = new System.Drawing.Point(0, 0);
            this.pict_MapView.Name = "pict_MapView";
            this.pict_MapView.Size = new System.Drawing.Size(100, 50);
            this.pict_MapView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pict_MapView.TabIndex = 0;
            this.pict_MapView.TabStop = false;
            // 
            // openXMLFileDialog
            // 
            this.openXMLFileDialog.FileName = "map.xml";
            this.openXMLFileDialog.Filter = "XML|*.xml|すべてのファイル|*.*";
            this.openXMLFileDialog.SupportMultiDottedExtensions = true;
            // 
            // saveXMLFileDialog
            // 
            this.saveXMLFileDialog.Filter = "XML|*.xml|すべてのファイル|*.*";
            this.saveXMLFileDialog.SupportMultiDottedExtensions = true;
            // 
            // outputTXTFileDialog
            // 
            this.outputTXTFileDialog.Filter = "TXT|*.txt|すべてのファイル|*.*";
            this.outputTXTFileDialog.SupportMultiDottedExtensions = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 473);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "MapEditor For C14";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Ypos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Xpos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_Radian)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_MapView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripButton btn_New;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btn_Open;
        private System.Windows.Forms.ToolStripButton btn_Save;
        private System.Windows.Forms.ToolStripButton btn_MapSize;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.RadioButton rbtn_Hero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbtn_Dyamic;
        private System.Windows.Forms.RadioButton rbtn_Static;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown num_Height;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown num_Width;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown num_Ypos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown num_Xpos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown num_Radian;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown num_ID;
        private System.Windows.Forms.PictureBox pict_MapView;
        private System.Windows.Forms.OpenFileDialog openXMLFileDialog;
        private System.Windows.Forms.SaveFileDialog saveXMLFileDialog;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.CheckBox chk_GridSnap;
        private System.Windows.Forms.Button btn_ObjDelete;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_Down48;
        private System.Windows.Forms.Button btn_Right48;
        private System.Windows.Forms.Button btn_wide568;
        private System.Windows.Forms.Button btn_wide284;
        private System.Windows.Forms.Button btn_wide192;
        private System.Windows.Forms.Button btn_wide48;
        private System.Windows.Forms.Button btn_Left48;
        private System.Windows.Forms.Button btn_Up48;
        private System.Windows.Forms.ToolStripButton btn_TXTOutput;
        private System.Windows.Forms.SaveFileDialog outputTXTFileDialog;
    }
}

