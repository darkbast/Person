﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MapEditorForC14
{
    public partial class MapSizeForm : Form
    {
        //プロパティ
        public int mapWidth
        {
            get { return (int)this.num_mapwidth.Value; }
            set { this.num_mapwidth.Value = value; }
        }
        public int mapHeight
        {
            get { return (int)this.num_mapheight.Value; }
            set { this.num_mapheight.Value = value; }
        }

        //コンストラクタ
        public MapSizeForm()
        {
            InitializeComponent();
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            Form1 owner = (Form1)this.Owner;
            owner.mapWidth = this.mapWidth;
            owner.mapHeight = this.mapHeight;
        }


    }
}
