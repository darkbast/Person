﻿namespace MapEditorForC14
{
    partial class MapSizeForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_ok = new System.Windows.Forms.Button();
            this.num_mapheight = new System.Windows.Forms.NumericUpDown();
            this.num_mapwidth = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.num_mapheight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_mapwidth)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_cancel
            // 
            this.btn_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_cancel.Location = new System.Drawing.Point(97, 75);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(51, 23);
            this.btn_cancel.TabIndex = 11;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            // 
            // btn_ok
            // 
            this.btn_ok.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_ok.Location = new System.Drawing.Point(47, 75);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(36, 23);
            this.btn_ok.TabIndex = 10;
            this.btn_ok.Text = "OK";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // num_mapheight
            // 
            this.num_mapheight.Location = new System.Drawing.Point(47, 34);
            this.num_mapheight.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.num_mapheight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_mapheight.Name = "num_mapheight";
            this.num_mapheight.Size = new System.Drawing.Size(72, 19);
            this.num_mapheight.TabIndex = 9;
            this.num_mapheight.Value = new decimal(new int[] {
            480,
            0,
            0,
            0});
            // 
            // num_mapwidth
            // 
            this.num_mapwidth.Location = new System.Drawing.Point(47, 7);
            this.num_mapwidth.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.num_mapwidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_mapwidth.Name = "num_mapwidth";
            this.num_mapwidth.Size = new System.Drawing.Size(72, 19);
            this.num_mapwidth.TabIndex = 8;
            this.num_mapwidth.Value = new decimal(new int[] {
            640,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "高さ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "幅";
            // 
            // MapSizeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(163, 109);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.num_mapheight);
            this.Controls.Add(this.num_mapwidth);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "MapSizeForm";
            this.Text = "MapSizeForm";
            ((System.ComponentModel.ISupportInitialize)(this.num_mapheight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_mapwidth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.NumericUpDown num_mapheight;
        private System.Windows.Forms.NumericUpDown num_mapwidth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}