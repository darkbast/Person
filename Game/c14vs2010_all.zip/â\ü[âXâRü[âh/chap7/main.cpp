#include "main.h"

//�O���[�o���ϐ�
GameState g_gamestate = GAME_TITLE;

//box2d�֘A
b2Vec2 gravity(0.0f, GRAVITY_Y);	//�d�͉����x
b2World g_world(gravity, true);		//Box2DWorld

//�Q�[���f�[�^
Images g_images;		//�摜�f�[�^
Sounds g_sounds;		//�����f�[�^
StageInfo g_stage;		//�X�e�[�W�f�[�^
int g_curstage = 0;		//���݂̃X�e�[�W
const int MAXSTAGE = 2;	//�ő�X�e�[�W��
char *g_mapfile[] = 
	{"media\\stage01.txt", "media\\stage02.txt"};

//���C�����[�v
void MyMain(){
	//�Q�[���J�n����̎��Ԃ��v��
	g_stage.gametime = g_lasttime - g_stage.gamestarttime;
	//b2b�̎��Ԃ�i�߂�
	g_world.Step(g_frametime, VELOCITYITE, POSITIONITE);
	//�e��ʂ̕`��
	switch(g_gamestate){
	case GAME_TITLE:
		DrawGameTitle();
		break;
	case GAME_MAIN:
		DrawGameMain();
		break;
	case GAME_CLEAR:
		DrawGameClear();
		break;
	case GAME_OVER:
		DrawGameOver();
		break;
	}
}

//�t�@�C���̓ǂݍ���
int LoadFiles(){
	//�t�@�C���ǂݍ��ݏ����������ɏ���
	g_images.logo[0] = LoadGraph("media\\morter_robo.png");
	if(g_images.logo[0] == -1) return -1;
	g_images.logo[1] = LoadGraph("media\\gameclear.png");
	if(g_images.logo[1] == -1) return -1;
	g_images.logo[2] = LoadGraph("media\\gameover.png");
	if(g_images.logo[2] == -1) return -1;
	//���{�p�[�c�ǂݍ���
	g_images.robo[ROBO_BODY] = LoadGraph("media\\robo_part0.png");
	if(g_images.robo[ROBO_BODY] == -1) return -1;
	g_images.robo[ROBO_HEAD] = LoadGraph("media\\robo_part1.png");
	if(g_images.robo[ROBO_HEAD] == -1) return -1;
	g_images.robo[ROBO_ROCKET] = LoadGraph("media\\robo_part2.png");
	if(g_images.robo[ROBO_ROCKET] == -1) return -1;
	g_images.robo[ROBO_SHOULDER] = LoadGraph("media\\robo_part3.png");
	if(g_images.robo[ROBO_SHOULDER] == -1) return -1;
	g_images.robo[ROBO_ARM] = LoadGraph("media\\robo_part4.png");
	if(g_images.robo[ROBO_ARM] == -1) return -1;
	g_images.robo[ROBO_HAND] = LoadGraph("media\\robo_part5.png");
	if(g_images.robo[ROBO_HAND] == -1) return -1;
	g_images.robo[ROBO_SHAFT] = LoadGraph("media\\robo_part6.png");
	if(g_images.robo[ROBO_SHAFT] == -1) return -1;
	g_images.robo[ROBO_CHASSIS] = LoadGraph("media\\robo_part7.png");
	if(g_images.robo[ROBO_CHASSIS] == -1) return -1;
	g_images.robo[ROBO_REARWHEEL] = LoadGraph("media\\robo_part89.png");
	if(g_images.robo[ROBO_REARWHEEL] == -1) return -1;
	g_images.robo[ROBO_FRONTWHEEL] = g_images.robo[ROBO_REARWHEEL];
	//���P�b�g����
	g_images.rocketfire = LoadGraph("media\\rocket_fire.png");
	if(g_images.rocketfire == -1) return -1;
	//�w�i�͗l�̓ǂݍ���
	g_images.back[0] = LoadGraph("media\\back_cross.png");
	if(g_images.back[0] == -1) return -1;
	//�}�b�v�摜�ǂݍ���
	g_images.map[MAP_192] = LoadGraph("media\\map_192.png");
	if(g_images.map[MAP_192] == -1) return -1;
	//�����ǂݍ���
	g_images.map[BUILDING_ALL] = LoadGraph("media\\building_s.png");
	if(g_images.map[BUILDING_ALL] == -1) return -1;
	g_images.map[BUILDING_24] = DerivationGraph(0,0,24,24, 
		g_images.map[BUILDING_ALL]);
	g_images.map[BUILDING_48] = DerivationGraph(0,24,24,48, 
		g_images.map[BUILDING_ALL]);
	g_images.map[BUILDING_96] = DerivationGraph(24,0,12,96, 
		g_images.map[BUILDING_ALL]);
	g_images.map[BUILDING_128] = DerivationGraph(36,0,12,128, 
		g_images.map[BUILDING_ALL]);
	//�G�ǂݍ���
	g_images.enemy = LoadGraph("media\\enemy.png");
	if(g_images.enemy == -1) return -1;
	
	//�����ǂݍ���
	g_sounds.car = LoadSoundMem("media\\tm2_car000.wav");
	if(g_sounds.car == -1) return -1;
	g_sounds.rocket = LoadSoundMem("media\\tm2_bom002.wav");
	if(g_sounds.rocket == -1) return -1;
	g_sounds.sonic = LoadSoundMem("media\\tm2_sonic000.wav");
	if(g_sounds.sonic == -1) return -1;
	g_sounds.punch = LoadSoundMem("media\\tm2_bom001.wav");
	if(g_sounds.punch == -1) return -1;
	g_sounds.fall = LoadSoundMem("media\\fall05.mp3");
	if(g_sounds.fall == -1) return -1;
	g_sounds.crash = LoadSoundMem("media\\tm2_gun002.wav");
	if(g_sounds.crash == -1) return -1;
	g_sounds.don = LoadSoundMem("media\\tm2_wood000.wav");
	if(g_sounds.don == -1) return -1;
	
	//�ǂݍ��ݐ���
	return 1;
}

//�X�e�[�W������
void InitStage(){
	//�Q�[���f�[�^�S�̂̃[��������
	ZeroMemory(&g_stage, sizeof(g_stage));
	//�S�{�f�B�E�W���C���g�폜
	DeleteAllBody();

	//�}�b�v�f�[�^�̓ǂݍ���
	if(LoadMapData(g_mapfile[g_curstage])==-1){
		MessageBox(NULL, "�n�`�f�[�^�ǂݍ��݃G���[", "", MB_OK);
	}
	//���{�f�[�^�̓ǂݍ���
	if( LoadRobo("media\\robo.txt") == -1){
		MessageBox(NULL, "���{�f�[�^�ǂݍ��݃G���[", "", MB_OK);
	}

	//�Q�[���J�n�����̋L�^
	g_stage.gamestarttime = g_lasttime;
}

//���{�f�[�^��ǂݍ���
int LoadRobo(char *filepath){
	int f;	//�t�@�C���n���h��
	char buf[1024];	//�e�L�X�g�ǂݍ��݃o�b�t�@

	f = FileRead_open(filepath);
	if (f==0) return -1;	//�ǂݍ��݃G���[

	//�}�b�v�T�C�Y�Ǝ�l�������ʒu�ǂݍ��݁i�g��Ȃ��j
	if(FileRead_gets( buf, 1023, f ) == -1) return -1;

	//�ÓI�I�u�W�F�N�g�ǂݍ���
	if(FileRead_gets( buf, 1023, f ) == -1) return -1;
	int imax;
	sscanf_s(buf, "%d" , &imax);	//�s���擾
	Character ch;
	float x, y, w, h, angle; 
	int id;
	float origin_x, origin_y;		//�{�f�B�̌��_
	for(int i=0; i<imax; i++){
		if(FileRead_gets( buf, 1023, f ) == -1) return -1;
		sscanf_s( buf, "%f, %f, %f, %f, %f, %d", 
			&x, &y, &w, &h, &angle, &id);
		//�{�f�B�쐬
		switch(id){
		case ROBO_BODY:		//����
			origin_x = x - g_stage.robostartx;
			origin_y = y - g_stage.robostarty;
			x = g_stage.robostartx;
			y = g_stage.robostarty;
			ch.body = CreateBody(PHS(x), PHS(y), 
				PHS(w/2), PHS(h/2), angle, true, true,
				30.0f, 0.2f, 2, 1);
			ch.used = true;
			ch.type = ROBO_BODY;
			g_stage.robo[ROBO_BODY] = ch;
			break;
		case ROBO_HEAD:	//��
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, true,
				10.0f, 0.2f, 2, 1);
			ch.used = true;
			ch.type = ROBO_HEAD;
			g_stage.robo[ROBO_HEAD] = ch;
			break;
		case ROBO_ROCKET:	//���P�b�g
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, false,
				10.0f, 0.2f, 2, 1);
			ch.used = true;
			ch.type = ROBO_ROCKET;
			g_stage.robo[ROBO_ROCKET] = ch;
			break;
		case ROBO_SHOULDER:	//��
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, true,
				10.0f, 0.2f, 4, 1);
			ch.used = true;
			ch.type = ROBO_SHOULDER;
			g_stage.robo[ROBO_SHOULDER] = ch;
			break;
		case ROBO_ARM:	//�r
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, false,
				10.0f, 0.2f, 4, 1);
			ch.used = true;
			ch.type = ROBO_ARM;
			g_stage.robo[ROBO_ARM] = ch;
			break;
		case ROBO_HAND:	//��
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, false,
				10.0f, 0.2f, 4, 1);
			ch.used = true;
			ch.type = ROBO_HAND;
			g_stage.robo[ROBO_HAND] = ch;
			break;
		case ROBO_SHAFT:	//�V���t�g
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, false,
				300.0f, 0.2f, 2, 1);
			ch.used = true;
			ch.type = ROBO_SHAFT;
			g_stage.robo[ROBO_SHAFT] = ch;
			break;
		case ROBO_CHASSIS: //�V���[�V
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, false,
				300.0f, 0.2f, 2, 1);
			ch.used = true;
			ch.type = ROBO_CHASSIS;
			g_stage.robo[ROBO_CHASSIS] = ch;
			break;
		case ROBO_REARWHEEL:	//���
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, true,
				100.0f, 0.2f, 2, 1);
			ch.used = true;
			ch.type = ROBO_REARWHEEL;
			g_stage.robo[ROBO_REARWHEEL] = ch;
			break;
		case ROBO_FRONTWHEEL:	//�O��
			x -= origin_x;
			y -= origin_y;
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, true,
				100.0f, 0.2f, 2, 1);
			ch.used = true;
			ch.type = ROBO_FRONTWHEEL;
			g_stage.robo[ROBO_FRONTWHEEL] = ch;
			break;
		}
	}
	//�W���C���g�쐬
	b2WeldJointDef wjointdef;
	wjointdef.Initialize(g_stage.robo[ROBO_BODY].body,
		g_stage.robo[ROBO_HEAD].body, 
		g_stage.robo[ROBO_HEAD].body->GetPosition());
	wjointdef.collideConnected = false;
	g_world.CreateJoint(&wjointdef);
	wjointdef.Initialize(g_stage.robo[ROBO_BODY].body,
		g_stage.robo[ROBO_ROCKET].body, 
		g_stage.robo[ROBO_ROCKET].body->GetPosition());
	g_world.CreateJoint(&wjointdef);
	wjointdef.Initialize(g_stage.robo[ROBO_SHOULDER].body,
		g_stage.robo[ROBO_ARM].body, 
		g_stage.robo[ROBO_SHOULDER].body->GetPosition());
	g_world.CreateJoint(&wjointdef);
	wjointdef.Initialize(g_stage.robo[ROBO_ARM].body,
		g_stage.robo[ROBO_HAND].body, 
		g_stage.robo[ROBO_HAND].body->GetPosition());
	g_world.CreateJoint(&wjointdef);
	wjointdef.Initialize(g_stage.robo[ROBO_BODY].body,
		g_stage.robo[ROBO_SHAFT].body, 
		g_stage.robo[ROBO_SHAFT].body->GetPosition());
	g_world.CreateJoint(&wjointdef);
	wjointdef.Initialize(g_stage.robo[ROBO_SHAFT].body,
		g_stage.robo[ROBO_CHASSIS].body, 
		g_stage.robo[ROBO_CHASSIS].body->GetPosition());
	g_world.CreateJoint(&wjointdef);
	//���֐߂��쐬
	b2RevoluteJointDef rjointdef;
	rjointdef.Initialize(g_stage.robo[ROBO_BODY].body,
		g_stage.robo[ROBO_SHOULDER].body,
		g_stage.robo[ROBO_SHOULDER].body->GetPosition());
	rjointdef.collideConnected = false;
	rjointdef.enableMotor = true;
	rjointdef.enableLimit = false;
	rjointdef.maxMotorTorque = 0.0f;
	g_stage.shoulder_jnt = (b2RevoluteJoint *)
		g_world.CreateJoint(&rjointdef);
	//��ւ��쐬
	rjointdef.Initialize(g_stage.robo[ROBO_CHASSIS].body,
		g_stage.robo[ROBO_REARWHEEL].body,
		g_stage.robo[ROBO_REARWHEEL].body->GetPosition());
	rjointdef.maxMotorTorque = 5000.0f;
	g_stage.rear_jnt = (b2RevoluteJoint *)
		g_world.CreateJoint(&rjointdef);
	//�O�ւ��쐬
	rjointdef.Initialize(g_stage.robo[ROBO_CHASSIS].body,
		g_stage.robo[ROBO_FRONTWHEEL].body,
		g_stage.robo[ROBO_FRONTWHEEL].body->GetPosition());
	g_stage.front_jnt = (b2RevoluteJoint *)
		g_world.CreateJoint(&rjointdef);
	//�`�揇�̐ݒ�
	int draworder[] = {
		ROBO_HEAD, ROBO_ROCKET, ROBO_SHAFT,
		ROBO_BODY,  
		ROBO_CHASSIS, ROBO_REARWHEEL, ROBO_FRONTWHEEL,
		ROBO_ARM, ROBO_SHOULDER, ROBO_HAND
	};
	memcpy_s(g_stage.robo_draworder, sizeof(g_stage.robo_draworder),
		draworder, sizeof(draworder));

	FileRead_close(f);
	return 0;
}
//�}�b�v�̓ǂݍ���
int LoadMapData(char *filepath){
	int f;	//�t�@�C���n���h��
	char buf[1024];	//�e�L�X�g�ǂݍ��݃o�b�t�@

	f = FileRead_open(filepath);
	if (f==0) return -1;	//�ǂݍ��݃G���[

	//�}�b�v�T�C�Y�Ǝ�l�������ʒu�ǂݍ���
	if(FileRead_gets( buf, 1023, f ) == -1) return -1;
	float w, h, sx, sy;
	sscanf_s(buf, "%f, %f, %f, %f", &w, &h, &sx, &sy);
	g_stage.mapsize_w = w;
	g_stage.mapsize_h = h;

	//���{�o���ʒu
	g_stage.robostartx = sx;
	g_stage.robostarty = sy;

	//�n�`�I�u�W�F�N�g�ǂݍ���
	if(FileRead_gets( buf, 1023, f ) == -1) return -1;
	int imax;
	sscanf_s(buf, "%d" , &imax);	//�s���擾
	float x, y, angle; 
	int id;
	for(int i=0; i<imax; i++){
		if(FileRead_gets( buf, 1023, f ) == -1) return -1;
		sscanf_s( buf, "%f, %f, %f, %f, %f, %d", 
			&x, &y, &w, &h, &angle, &id);
		//�{�f�B�쐬
		Character ch;
		switch(id){
		case 0:	//�n�`
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, false, false, 
				0, 0.2f, 1, 1+2+4);
			ch.type = MAP_GROUND;
			ch.ID = MAP_192;
			ch.used = true;
			g_stage.map[g_stage.num_mapchara] = ch;
			ch.body->SetUserData(
				&g_stage.map[g_stage.num_mapchara]);
			g_stage.num_mapchara++;		
			break;
		case 1:	//�r���f�B���O
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, false, 
				200.0f, 0.2f, 1, 1+2+4);
			ch.type = MAP_BUILDING;
			if((int)h == 24) ch.ID = BUILDING_24;
			if((int)h == 48) ch.ID = BUILDING_48;
			if((int)h == 96) ch.ID = BUILDING_96;
			if((int)h == 128) ch.ID = BUILDING_128;
			ch.used = true;
			g_stage.map[g_stage.num_mapchara] = ch;
			ch.body->SetUserData(
				&g_stage.map[g_stage.num_mapchara]);
			g_stage.num_mapchara++;		
			break;
		case 2:	//�C���x�[�_�[
			ch.body = CreateBody(PHS(x), PHS(y),
				PHS(w/2), PHS(h/2), angle, true, false, 
				1.0f, 0.2f, 1, 1+2+4);
			ch.type = MAP_INVADER;
			ch.ID = 0;
			ch.used = true;
			g_stage.map[g_stage.num_mapchara] = ch;
			ch.body->SetUserData(
				&g_stage.map[g_stage.num_mapchara]);
			g_stage.num_mapchara++;		
			g_stage.num_invader++;
			break;
		}
	}
	
	FileRead_close(f);
	return 0;
}
//�^�C�g����ʕ`��
void GoGameTitle(){
	g_gamestate = GAME_TITLE;
}
void DrawGameTitle(){
	//�F�A�j���[�V����
	float anim = (float)((g_lasttime / (1000 / 48)) % 200) / 100;
	if (anim > 1.0f) anim = 2.0f - anim;
	int r = (int)(140 * anim);
	int g = (int)(140 * anim);
	int b = (int)(255 * anim);
	int col = GetColor(r, g, b);
	DrawBox(0, 0, 640, 480, col, TRUE);
	//�摜�\��
	DrawGraph(0, 10, g_images.logo[0], TRUE);
	//�e�L�X�g�\��
	DrawStringToHandle(20, 350, 
		"���A���L�[�őO��ړ��@���A���L�[�Řr����", 
		0xFFFF00, g_middlefont);
	DrawStringToHandle(20, 390, "X�L�[�Ń��P�b�g���ˁAC�L�[�Ńp���`", 
		0xFFFF00, g_middlefont);
	DrawStringToHandle(20, 430, "Z�L�[�ŃQ�[���X�^�[�g", 
		0xFFFF00, g_middlefont);
	//�L�[���`�F�b�N���ĉ�ʐ؂�ւ�
	int key = GetJoypadInputState( DX_INPUT_KEY_PAD1 );
	if(IsAKeyTrigger(key)==true) GoGameMain();
}
//�Q�[���{�ҕ`��
void GoGameMain(){
	g_gamestate = GAME_MAIN;
	InitStage();	//�X�e�[�W�f�[�^�̏�����
}
void DrawGameMain(){
	//�X�N���[�����W����
	b2Vec2 pos = g_stage.robo[ROBO_BODY].body->GetPosition();
	int hx = (int)(pos.x * WLDSC);
	int hy = (int)(pos.y * WLDSC);
	g_stage.screen_x = hx - 240;
	if(	hy - SCROLL_LIMIT < g_stage.screen_y ){
		g_stage.screen_y = hy - SCROLL_LIMIT;
	}
	if( 480 - SCROLL_LIMIT < hy - g_stage.screen_y ){
		g_stage.screen_y = hy + SCROLL_LIMIT - 480;
	}
	//�Փ˔���
	Collision();
	//�n�`�`��
	DrawMapAndEnemy();
	//���{�b�g�`��
	DrawRobo();
	//���[�U�[����
	PlayerMove();
}

//���{�b�g�`��
void DrawRobo(){
	b2Vec2 pos;
	float angle;
	//���P�b�g���˕`��
	if( g_stage.rockettime > g_lasttime){
		pos = g_stage.robo[ROBO_ROCKET].body->GetPosition();
		angle = g_stage.robo[ROBO_ROCKET].body->GetAngle();
		DrawRotaGraph(VIWX(pos.x), VIWY(pos.y),1, angle, 
			g_images.rocketfire, TRUE, FALSE);		
	}
	//���{�b�g�{�̕`��
	for(int i=0; i<10; i++){
		int order = g_stage.robo_draworder[i];
		if(g_stage.robo[order].used == false) continue;
		pos = g_stage.robo[order].body->GetPosition();
		angle = g_stage.robo[order].body->GetAngle();
		DrawRotaGraph(VIWX(pos.x), VIWY(pos.y),1, angle, 
			g_images.robo[order], TRUE, FALSE);
	}
}
//�n�`�`��
void DrawMapAndEnemy(){
	//�w�i�̕`��
	for(int x=0; x<6; x++){
		for(int y=0; y<5; y++){
			int delta = (g_lasttime / (1000 / 30)) % 128;
			DrawGraph( x*128 - delta, y*128 - delta, 
				g_images.back[0], FALSE);
		}
	}

	b2Vec2 pos;
	float angle;
	for(int i=0; i<g_stage.num_mapchara; i++){
		if(g_stage.map[i].used == false) continue;
		pos = g_stage.map[i].body->GetPosition();
		angle = g_stage.map[i].body->GetAngle();
		int id = g_stage.map[i].ID;
		//�^�C�v�ʂɕ`��
		switch(g_stage.map[i].type){
		case MAP_GROUND:
			DrawRotaGraph(VIWX(pos.x), VIWY(pos.y),1, angle, 
				g_images.map[id], TRUE, FALSE);
			break;
		case MAP_BUILDING:
			DrawRotaGraph(VIWX(pos.x), VIWY(pos.y),1, angle, 
				g_images.map[id], TRUE, FALSE);
			//�j��`�F�b�N
			if(g_stage.map[i].damage > 600.0f){
				g_world.DestroyBody(g_stage.map[i].body);
				g_stage.map[i].used = false;
				//���ʉ�
				PlaySoundMem(g_sounds.crash, DX_PLAYTYPE_BACK);
			}
			break;
		case MAP_INVADER:
			DrawRotaGraph(VIWX(pos.x), VIWY(pos.y),1, angle, 
				g_images.enemy, TRUE, FALSE);
			//�j��`�F�b�N
			if(g_stage.map[i].damage > 10.0f ||
				IsOutScreen(pos.x, pos.y)){
				g_world.DestroyBody(g_stage.map[i].body);
				g_stage.map[i].used = false;
				g_stage.num_invader--;
				//���ʉ�
				PlaySoundMem(g_sounds.sonic, DX_PLAYTYPE_BACK);
			}
			break;
		}
	}
}
//���[�U�[����
void PlayerMove(){
	int key = GetJoypadInputState( DX_INPUT_KEY_PAD1 );
	//�ԗ�
	if(key & PAD_INPUT_RIGHT){
		g_stage.front_jnt->SetMotorSpeed(b2_pi);
		g_stage.rear_jnt->SetMotorSpeed(b2_pi);
		//���ʉ�
		if(CheckSoundMem(g_sounds.car)==0){
			PlaySoundMem(g_sounds.car, DX_PLAYTYPE_BACK);
		}
	} else if(key & PAD_INPUT_LEFT){
		g_stage.front_jnt->SetMotorSpeed(-b2_pi);
		g_stage.rear_jnt->SetMotorSpeed(-b2_pi);
		//���ʉ�
		if(CheckSoundMem(g_sounds.car)==0){
			PlaySoundMem(g_sounds.car, DX_PLAYTYPE_BACK);
		}
	} else {
		g_stage.front_jnt->SetMotorSpeed(0);
		g_stage.rear_jnt->SetMotorSpeed(0);
		StopSoundMem(g_sounds.car);//���ʉ�
	}
	//�r
	if(key & PAD_INPUT_DOWN){
		g_stage.shoulder_jnt->SetMaxMotorTorque(5000.0f);
		g_stage.shoulder_jnt->SetMotorSpeed(b2_pi/3);
	} else if(key & PAD_INPUT_UP){
		g_stage.shoulder_jnt->SetMaxMotorTorque(5000.0f);
		g_stage.shoulder_jnt->SetMotorSpeed(-b2_pi/3);
	} else {
		g_stage.shoulder_jnt->SetMaxMotorTorque(0);
		g_stage.shoulder_jnt->SetMotorSpeed(0);
	}
	//���P�b�g��]�p���`
	if(IsCKeyTrigger(key)==true){
		b2Vec2 pos = g_stage.robo[ROBO_HAND].body->GetPosition();
		float angle =  g_stage.robo[ROBO_HAND].body->GetAngle();
		b2Vec2 rocketv;
		rocketv.x = 0;
		rocketv.y = 2500.0f;
		b2Mat22 rot(-angle);
		b2Vec2 rocketv2 = rot.Solve(rocketv);
		g_stage.robo[ROBO_HAND].body->
			ApplyLinearImpulse(rocketv2, pos);	
		//���ʉ�
		PlaySoundMem(g_sounds.punch, DX_PLAYTYPE_BACK);
	}

	//���݂̍��W�Ɗp�x���擾
	b2Vec2 pos = g_stage.robo[ROBO_BODY].body->GetPosition();
	float angle =  g_stage.robo[ROBO_BODY].body->GetAngle();
	//���P�b�g����
	if(IsBKeyTrigger(key)==true)
	{
		b2Vec2 rocketv;
		rocketv.x = 2000.0f;
		rocketv.y = -8000.0f;
		b2Mat22 rot(-angle);
		b2Vec2 rocketv2 = rot.Solve(rocketv);
		pos.x += PHS(40);//�d�S����
		pos.y += PHS(40);
		g_stage.robo[ROBO_BODY].body->
			ApplyLinearImpulse(rocketv2, pos);		
		//���ˉ��̕\��
		g_stage.rockettime = g_lasttime + 1000;
		//���ʉ�
		PlaySoundMem(g_sounds.rocket, DX_PLAYTYPE_BACK);
	}
	//�Q�[���I�[�o�[�m�F
	if( IsOutScreen(pos.x, pos.y) == true){
		GoGameOver();
	}
	//�Q�[���N���A�m�F
	if( g_stage.num_invader < 1 ) GoGameClear();
}
//�Փ˔���
void Collision(){
	//�ڐG�m�F���[�v
	for(b2Contact* c = g_world.GetContactList(); c!=NULL; 
		c = c->GetNext())
	{
		if(c->IsTouching() == false) continue;
		//�ڐG���Ă���{�f�B�����o��
		b2Body* bd[2];
		bd[0] = c->GetFixtureA()->GetBody();
		bd[1] = c->GetFixtureB()->GetBody();
		//�{�f�B�`�F�b�N
		for(int i=0; i<2; i++){
			Character *ch = (Character *)bd[i]->GetUserData();
			if(ch != NULL){
				//�C���x�[�_�[���r���f�B���O�Ȃ�Ռ����L�^
				if( ch->type == MAP_INVADER ||
					ch->type == MAP_BUILDING)
				{
					b2Manifold *m = m = c->GetManifold();
					float ni = m->points[0].normalImpulse;
					//2�_�̂����傫���ق������
					if( m->pointCount>1 && 
						ni < m->points[1].normalImpulse)
					{
						ni = m->points[1].normalImpulse;
					}
					ch->damage = ni;
					//���ʉ�
					if( ni > 200.0f && 
						CheckSoundMem(g_sounds.don)==0)
					{
						PlaySoundMem(g_sounds.don, DX_PLAYTYPE_BACK);
					}
				}
			}
		}
	}	
}


//�Q�[���N���A��ʕ`��
void GoGameClear(){
	g_gamestate = GAME_CLEAR;
	g_stage.timerstart = g_lasttime;
	//�X�e�[�W��i�߂�
	g_curstage++;
	g_curstage %= MAXSTAGE;
}
void DrawGameClear(){
	DrawMapAndEnemy();
	DrawRobo();
	DrawGraph(20,160,g_images.logo[1], TRUE);
	//5�b�o������^�C�g����ʂ�
	if(g_lasttime - g_stage.timerstart > 5000) GoGameTitle();
}
//�Q�[���I�[�o�[��ʕ`��
void GoGameOver(){
	g_gamestate = GAME_OVER;
	g_stage.timerstart = g_lasttime;
	//���ʉ�
	PlaySoundMem(g_sounds.fall, DX_PLAYTYPE_BACK);
}
void DrawGameOver(){
	DrawMapAndEnemy();
	DrawRobo();
	DrawGraph(27,160,g_images.logo[2], TRUE);
	//5�b�o������^�C�g����ʂ�
	if(g_lasttime - g_stage.timerstart > 5000) GoGameTitle();
}

b2Body* CreateBody(float x, float y, float w, float h, float angle,
	bool dynamic, bool isball, float density, float restitution,
	int categoryBits, int maskBits)
{
	//�{�f�B��`
	b2BodyDef bodyDef;
	bodyDef.type = b2_dynamicBody;	//���I�{�f�B
	bodyDef.position.Set(x, y);
	bodyDef.angle = angle;
	if(dynamic) bodyDef.type = b2_dynamicBody;	//���I�{�f�B 
	else bodyDef.type = b2_staticBody;	//�ÓI�{�f�B
	//�{�f�B�쐬
	b2Body* body = g_world.CreateBody(&bodyDef);
	//�t�B�N�X�`����`
	b2FixtureDef fixtureDef;
	//�V�F�C�v�쐬�itrue�Ȃ�~�Afalse�Ȃ璷���`�j
	b2CircleShape dynamicBall;
	dynamicBall.m_radius = w;
	b2PolygonShape staticBox;
	staticBox.SetAsBox(w, h);
	if(isball){
		fixtureDef.shape = &dynamicBall;
	} else {
		fixtureDef.shape = &staticBox;
	}
	fixtureDef.density = density;		 //���x
	fixtureDef.restitution = restitution;//������
	fixtureDef.friction = 0.6f;			//���C��
	fixtureDef.filter.categoryBits = categoryBits;
	fixtureDef.filter.maskBits = maskBits;
	body->CreateFixture(&fixtureDef);
	return body;
}
